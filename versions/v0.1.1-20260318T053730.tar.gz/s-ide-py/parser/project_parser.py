"""
parser/project_parser.py
=========================
Orchestrator: ties together the walker, per-language parsers, edge
resolver, layout engine, and doc auditor into a single parse pass.

Usage
-----
    from parser.project_parser import parse_project

    graph = parse_project("/path/to/project")
    # graph is a ProjectGraph; call graph.to_dict() for JSON output

Parse pipeline
--------------
1. init_project_config  — load/create side.project.json
2. walk_directory       — discover all source files
3. per-file parsing     — call the appropriate language parser
4. build FileNodes      — wrap parser output in typed dataclasses
5. resolve_edges        — turn raw import strings into graph edges
6. assign_positions     — auto-layout for the node editor
7. audit_docs           — README / empty-module health check
8. return ProjectGraph

Performance note
----------------
Parsing is synchronous and single-threaded. For typical projects
(< 2000 files) this completes in well under a second. If you need
async/parallel parsing in future, each per-file parse call is
independently safe to run in a thread pool.
"""

from __future__ import annotations
import os
import time
from datetime import datetime, timezone

from parser.walker import walk_directory, make_node_id
from parser.parsers import PARSERS
from parser.resolve_edges import resolve_edges
from parser.layout import assign_positions
from parser.doc_check import audit_docs
from parser.project_config import init_project_config

from graph.types import (
    FileNode, ImportRecord, ExportRecord, Definition,
    GraphMeta, ProjectGraph,
)


def _read_safe(path: str) -> str | None:
    """Read a text file, returning None on any error."""
    try:
        with open(path, "r", encoding="utf-8", errors="replace") as f:
            return f.read()
    except Exception:
        return None


def _file_stats(path: str) -> tuple[int, str | None]:
    """Return (size_bytes, iso_mtime) or (0, None) on error."""
    try:
        stat = os.stat(path)
        mtime = datetime.fromtimestamp(stat.st_mtime, tz=timezone.utc).isoformat()
        return stat.st_size, mtime
    except Exception:
        return 0, None


def _make_node(file_info, parsed: dict, size: int, mtime: str | None, content: str | None) -> FileNode:
    """Construct a FileNode from raw file info + parser output."""
    lines = content.count("\n") + 1 if content else 0

    def to_import(r) -> ImportRecord:
        if isinstance(r, ImportRecord):
            return r
        return ImportRecord(**r)

    def to_export(r) -> ExportRecord:
        if isinstance(r, ExportRecord):
            return r
        return ExportRecord(**r)

    def to_def(r) -> Definition:
        if isinstance(r, Definition):
            return r
        return Definition(**r)

    return FileNode(
        id=make_node_id(file_info.relative_path),
        label=file_info.name,
        path=file_info.relative_path,
        full_path=file_info.full_path,
        category=file_info.category,
        ext=file_info.ext,
        lines=lines,
        size=size,
        modified=mtime,
        imports=[to_import(r) for r in (parsed.get("imports") or [])],
        exports=[to_export(r) for r in (parsed.get("exports") or [])],
        definitions=[to_def(r) for r in (parsed.get("definitions") or [])],
        tags=list(parsed.get("tags") or []),
        errors=list(parsed.get("errors") or []),
    )


def parse_project(root_dir: str) -> ProjectGraph:
    """
    Full parse pipeline for a project directory.
    Returns a ProjectGraph ready for JSON serialisation.
    """
    t_start = time.monotonic()
    root_dir = os.path.abspath(root_dir)

    # 1. Load / create project config
    config = init_project_config(root_dir)
    extra_ignore = list(config.get("ignore") or [])
    versions_dir = (config.get("versions") or {}).get("dir", "versions")
    if versions_dir and versions_dir not in extra_ignore:
        extra_ignore.append(versions_dir)

    # 2. Walk directory
    files = walk_directory(root_dir, extra_ignore=extra_ignore)

    # 3. Parse each file + build nodes
    nodes: list[FileNode] = []
    file_index: dict[str, str] = {}   # relative_path → node_id

    for file_info in files:
        content = _read_safe(file_info.full_path)
        size, mtime = _file_stats(file_info.full_path)

        parser_fn = PARSERS.get(file_info.ext)
        if parser_fn and content is not None:
            try:
                parsed = parser_fn(content, file_info.full_path)
            except Exception as exc:
                parsed = {
                    "imports": [], "exports": [], "definitions": [],
                    "tags": [], "errors": [f"Parser crash: {exc}"],
                }
        else:
            parsed = {"imports": [], "exports": [], "definitions": [],
                      "tags": [], "errors": []}

        node = _make_node(file_info, parsed, size, mtime, content)
        nodes.append(node)
        file_index[file_info.relative_path] = node.id

    # 4. Resolve edges
    edges = resolve_edges(nodes, file_index, root_dir)

    # 5. Auto-layout
    assign_positions(nodes, edges)

    # 6. Doc audit
    docs = audit_docs(root_dir, nodes)

    # 7. Language stats
    lang_stats: dict[str, dict] = {}
    for node in nodes:
        cat = node.category
        if cat not in lang_stats:
            lang_stats[cat] = {"files": 0, "lines": 0}
        lang_stats[cat]["files"] += 1
        lang_stats[cat]["lines"] += node.lines

    parse_ms = int((time.monotonic() - t_start) * 1000)

    meta = GraphMeta(
        root=root_dir,
        parsed_at=datetime.now(tz=timezone.utc).isoformat(),
        parse_time_ms=parse_ms,
        total_files=len(nodes),
        total_edges=len(edges),
        languages=lang_stats,
        docs=docs,
        project_name=config.get("name") or os.path.basename(root_dir),
        project_version=config.get("version") or "0.0.0",
        project_description=config.get("description") or "",
        project_run=dict(config.get("run") or {}),
        has_config=bool(config.get("_exists")),
    )

    return ProjectGraph(
        version="1.0.0",
        meta=meta,
        nodes=nodes,
        edges=edges,
    )
