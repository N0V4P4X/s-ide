# S-IDE — Python Core

Systematic Integrated Development Environment — backend core, Python rewrite.

## Architecture

```
s-ide-py/
├── parser/                  # Project analysis engine
│   ├── walker.py            # Directory traversal + file discovery
│   ├── project_config.py    # side.project.json read/write/init
│   ├── project_parser.py    # Orchestrator: walk → parse → build graph
│   ├── resolve_edges.py     # Import resolution → graph edges
│   ├── doc_check.py         # README / documentation health audit
│   ├── layout.py            # Auto-layout algorithm for node positions
│   └── parsers/
│       ├── python_parser.py # Python AST-based semantic extraction
│       ├── js_parser.py     # JavaScript/TS regex-based extraction
│       ├── json_parser.py   # JSON manifest extraction (package.json etc.)
│       └── shell_parser.py  # Shell script relationship extraction
│
├── graph/
│   └── types.py             # Dataclass definitions for Node, Edge, Graph
│
├── process/
│   └── process_manager.py   # Spawn / monitor / kill subprocesses
│
├── version/
│   └── version_manager.py   # Archive, extract, bump versions via tarballs
│
└── main.py                  # CLI entry point (parse | run | version)
```

## Data Model

The core output is a `ProjectGraph`:
- **nodes**: one per source file — contains imports, exports, definitions, tags, doc health
- **edges**: directed dependency relationships between nodes
- **meta**: project config, language stats, doc audit summary, parse timing

This structure feeds directly into the node editor visualizer.

## Usage

```bash
# Parse a project and emit graph JSON
python main.py parse /path/to/project

# Parse and write to specific output file
python main.py parse /path/to/project --out graph.json

# Apply a tarball update (archives first, then extracts, bumps version)
python main.py update /path/to/project update.tar.gz --bump patch

# List archived versions
python main.py versions /path/to/project

# Run a named script from side.project.json
python main.py run /path/to/project dev
```

## side.project.json

Each project can have a `side.project.json` config:

```json
{
  "name": "my-project",
  "version": "0.1.0",
  "description": "...",
  "ignore": ["dist", "*.test.py"],
  "run": {
    "dev":   "python main.py",
    "test":  "pytest"
  },
  "versions": {
    "dir":      "versions",
    "compress": true,
    "keep":     20
  }
}
```
