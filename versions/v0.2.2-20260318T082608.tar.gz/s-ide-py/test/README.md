# test/

Smoke tests for the parser pipeline.

## Run

```bash
node test/run.js
```

Expected output: `28 passed, 0 failed`

## What it tests

Parses the `nodegraph-parser` source tree (the parser's original home) and
validates the full output contract: meta shape, node shape, edge shape, and
parser quality (at least one node with imports, exports, and definitions).

The test is self-referential by design — if the JS parser breaks in a way
that affects its own source files, the test catches it.

## Running against s-ide itself

```bash
node --input-type=module <<'EOF'
import { parseProject } from './parser/projectParser.js';
const g = await parseProject('.');
console.log(g.nodes.length, 'nodes', g.edges.length, 'edges');
console.log('doc health:', g.meta.docs.summary);
EOF
```
