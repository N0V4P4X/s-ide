"""
gui/log.py
==========
S-IDE application logging.

Sets up a stdlib logger that simultaneously writes to:
  1. ~/.s-ide.log          — persistent file, rotated at 2MB / 3 backups
  2. An in-memory ring buffer (last 500 lines) for the in-app log panel

Usage
-----
    from gui.log import get_logger, get_log_path, recent_lines

    log = get_logger(__name__)
    log.info("Parser started")
    log.warning("README missing in src/")
    log.error("Parse failed: %s", exc)

    # In-app log panel reads recent_lines() for display
    lines = recent_lines()    # list of (level, message) tuples

Finding logs on disk
--------------------
The log file path is printed to stdout on first import and visible in
the in-app log panel header.  Default location:

    ~/.s-ide.log

On macOS/Linux you can tail it:
    tail -f ~/.s-ide.log

On Windows:
    Get-Content $env:USERPROFILE\\.s-ide.log -Wait
"""

from __future__ import annotations
import logging
import logging.handlers
import os
import sys
from collections import deque
from datetime import datetime

# ── File path ─────────────────────────────────────────────────────────────────
LOG_PATH = os.path.join(os.path.expanduser("~"), ".s-ide.log")
MAX_RING  = 500   # lines kept in memory for the in-app panel

# ── Ring buffer handler ───────────────────────────────────────────────────────
_ring: deque = deque(maxlen=MAX_RING)

class _RingHandler(logging.Handler):
    """Stores formatted records in a fixed-size deque."""
    def emit(self, record: logging.LogRecord) -> None:
        try:
            msg = self.format(record)
            _ring.append((record.levelname, msg))
        except Exception:
            pass


# ── Module-level setup (runs once on import) ──────────────────────────────────
_root_logger = logging.getLogger("side")
_root_logger.setLevel(logging.DEBUG)

_fmt = logging.Formatter(
    fmt="%(asctime)s %(levelname)-8s %(name)s — %(message)s",
    datefmt="%H:%M:%S",
)

# 1. Rotating file handler
try:
    _file_handler = logging.handlers.RotatingFileHandler(
        LOG_PATH, maxBytes=2 * 1024 * 1024, backupCount=3, encoding="utf-8"
    )
    _file_handler.setFormatter(_fmt)
    _root_logger.addHandler(_file_handler)
    _file_ok = True
except OSError as _e:
    _file_ok = False
    print(f"[s-ide] WARNING: Could not open log file {LOG_PATH}: {_e}", file=sys.stderr)

# 2. Ring buffer handler
_ring_handler = _RingHandler()
_ring_handler.setFormatter(_fmt)
_root_logger.addHandler(_ring_handler)

# 3. Stderr handler (only WARNING+ to avoid noise in terminals)
_stderr_handler = logging.StreamHandler(sys.stderr)
_stderr_handler.setLevel(logging.WARNING)
_stderr_handler.setFormatter(_fmt)
_root_logger.addHandler(_stderr_handler)

# Announce log file path to both the log and stderr (visible in terminal)
_startup_msg = f"S-IDE session started — log: {LOG_PATH}" if _file_ok else f"S-IDE session started — log file unavailable ({LOG_PATH})"
_root_logger.info(_startup_msg)
print(f"[s-ide] {_startup_msg}", file=sys.stderr, flush=True)


# ── Public API ────────────────────────────────────────────────────────────────

def get_logger(name: str) -> logging.Logger:
    """Return a child logger under the 'side' namespace."""
    return logging.getLogger(f"side.{name}")


def get_log_path() -> str:
    return LOG_PATH


def recent_lines(n: int = MAX_RING) -> list[tuple[str, str]]:
    """Return up to n recent (level, message) tuples, newest last."""
    items = list(_ring)
    return items[-n:] if len(items) > n else items


def clear_ring() -> None:
    _ring.clear()
