"""
test/test_suite.py
==================
S-IDE core test suite. Uses only stdlib (unittest) — no pytest required,
though pytest will discover and run these fine.

Test groups
-----------
TestPythonParser    — AST-based python_parser
TestJSParser        — regex-based js_parser
TestJSONParser      — json_parser (package.json, tsconfig, generic)
TestShellParser     — shell_parser
TestWalker          — directory walker ignore logic
TestProjectConfig   — side.project.json load/save/init/bump
TestResolveEdges    — import → edge resolution
TestLayout          — auto-layout position assignment
TestDocCheck        — README / empty-module audit
TestProjectParser   — full parse pipeline on a synthetic project
TestVersionManager  — archive, extract, list, compress
TestProcessManager  — spawn, logs, stop
"""

from __future__ import annotations
import json
import os
import sys
import tarfile
import tempfile
import time
import unittest

# ── Make sure parent dir is on sys.path so imports resolve ───────────────────
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if ROOT not in sys.path:
    sys.path.insert(0, ROOT)

# ── Imports under test ────────────────────────────────────────────────────────
from parser.parsers.python_parser import parse_python
from parser.parsers.js_parser import parse_javascript
from parser.parsers.json_parser import parse_json
from parser.parsers.shell_parser import parse_shell
from parser.walker import walk_directory, make_node_id, _should_ignore
from parser.project_config import load_project_config, save_project_config, init_project_config, bump_version
from parser.resolve_edges import resolve_edges, collect_external_packages
from parser.layout import assign_positions
from parser.doc_check import audit_docs
from parser.project_parser import parse_project
from version.version_manager import archive_version, apply_update, list_versions, compress_loose
from process.process_manager import ProcessManager
from graph.types import FileNode, Edge, Position, ImportRecord


# ── Helpers ───────────────────────────────────────────────────────────────────

def _tmp_project(*files: tuple[str, str]) -> tempfile.TemporaryDirectory:
    """
    Create a temporary directory pre-populated with (relative_path, content) files.
    Use as a context manager: `with _tmp_project(...) as tmp_dir: ...`
    The context variable is the directory path string.
    """
    tmp = tempfile.TemporaryDirectory()
    for rel_path, file_content in files:
        full = os.path.join(tmp.name, rel_path)
        os.makedirs(os.path.dirname(full), exist_ok=True)
        with open(full, "w", encoding="utf-8") as f:
            f.write(file_content)
    return tmp


# ═══════════════════════════════════════════════════════════════════════════════
# Parser tests
# ═══════════════════════════════════════════════════════════════════════════════

class TestPythonParser(unittest.TestCase):

    def test_basic_import(self):
        src = "import os\nimport sys\n"
        r = parse_python(src)
        sources = [i.source for i in r["imports"]]
        self.assertIn("os", sources)
        self.assertIn("sys", sources)

    def test_from_import(self):
        src = "from os.path import join, exists\n"
        r = parse_python(src)
        self.assertEqual(len(r["imports"]), 1)
        imp = r["imports"][0]
        self.assertEqual(imp.type, "from-import")
        self.assertEqual(imp.source, "os.path")
        self.assertIn("join", imp.names)

    def test_relative_import(self):
        src = "from . import utils\nfrom ..core import Base\n"
        r = parse_python(src)
        sources = [i.source for i in r["imports"]]
        self.assertIn(".", sources)
        self.assertIn("..core", sources)

    def test_function_definition(self):
        src = "def hello(name):\n    pass\n"
        r = parse_python(src)
        defs = [d.name for d in r["definitions"]]
        self.assertIn("hello", defs)

    def test_async_function(self):
        src = "async def fetch():\n    pass\n"
        r = parse_python(src)
        d = r["definitions"][0]
        self.assertTrue(d.is_async)
        self.assertEqual(d.name, "fetch")

    def test_class_with_base(self):
        src = "class Dog(Animal):\n    pass\n"
        r = parse_python(src)
        cls = r["definitions"][0]
        self.assertEqual(cls.kind, "class")
        self.assertIn("Animal", cls.bases)

    def test_dunder_method(self):
        src = "class Foo:\n    def __init__(self):\n        pass\n"
        r = parse_python(src)
        dunder = next(d for d in r["definitions"] if d.name == "__init__")
        self.assertEqual(dunder.kind, "dunder")

    def test_all_export(self):
        src = '__all__ = ["foo", "bar"]\ndef foo(): pass\ndef bar(): pass\n'
        r = parse_python(src)
        all_exp = next((e for e in r["exports"] if e.type == "__all__"), None)
        self.assertIsNotNone(all_exp)
        self.assertIn("foo", all_exp.names)

    def test_implicit_exports(self):
        src = "def public(): pass\ndef _private(): pass\n"
        r = parse_python(src)
        names = [e.name for e in r["exports"] if e.type == "implicit"]
        self.assertIn("public", names)
        self.assertNotIn("_private", names)

    def test_entrypoint_tag(self):
        src = "if __name__ == '__main__':\n    main()\n"
        r = parse_python(src)
        self.assertIn("entrypoint", r["tags"])

    def test_syntax_error_fallback(self):
        src = "def broken(\n    pass\n"
        r = parse_python(src)
        self.assertTrue(len(r["errors"]) > 0)

    def test_flask_tag(self):
        src = "from flask import Flask\n"
        r = parse_python(src)
        self.assertIn("flask", r["tags"])

    def test_star_import(self):
        src = "from utils import *\n"
        r = parse_python(src)
        self.assertEqual(r["imports"][0].type, "from-import-all")


class TestJSParser(unittest.TestCase):

    def test_es_default_import(self):
        src = "import React from 'react';\n"
        r = parse_javascript(src)
        self.assertEqual(r["imports"][0].type, "es-default")
        self.assertEqual(r["imports"][0].source, "react")

    def test_es_named_import(self):
        src = "import { useState, useEffect } from 'react';\n"
        r = parse_javascript(src)
        imp = r["imports"][0]
        self.assertEqual(imp.type, "es-named")
        self.assertIn("useState", imp.names)

    def test_cjs_require(self):
        src = "const path = require('path');\n"
        r = parse_javascript(src)
        self.assertEqual(r["imports"][0].type, "cjs-require")

    def test_export_default(self):
        src = "export default MyComponent;\n"
        r = parse_javascript(src)
        self.assertEqual(r["exports"][0].type, "default")
        self.assertEqual(r["exports"][0].name, "MyComponent")

    def test_reexport(self):
        src = "export { foo, bar } from './utils';\n"
        r = parse_javascript(src)
        exp = r["exports"][0]
        self.assertEqual(exp.type, "re-export")
        self.assertEqual(exp.source, "./utils")

    def test_function_def(self):
        src = "function greet(name) { return name; }\n"
        r = parse_javascript(src)
        self.assertIn("greet", [d.name for d in r["definitions"]])

    def test_comment_stripping(self):
        src = "// import foo from 'not-real';\nimport bar from 'real';\n"
        r = parse_javascript(src)
        sources = [i.source for i in r["imports"]]
        self.assertNotIn("not-real", sources)
        self.assertIn("real", sources)

    def test_react_tag(self):
        src = "import React from 'react';\n"
        r = parse_javascript(src)
        self.assertIn("react", r["tags"])


class TestJSONParser(unittest.TestCase):

    def test_package_json(self):
        src = json.dumps({
            "name": "my-app",
            "dependencies": {"express": "^4.0.0"},
            "scripts": {"start": "node index.js"},
        })
        r = parse_json(src, "package.json")
        self.assertIn("package-manifest", r["tags"])
        srcs = [i.source for i in r["imports"]]
        self.assertIn("express", srcs)
        script_names = [d.name for d in r["definitions"]]
        self.assertIn("start", script_names)

    def test_malformed_json(self):
        r = parse_json("{not valid}", "config.json")
        self.assertTrue(len(r["errors"]) > 0)

    def test_tsconfig(self):
        src = json.dumps({"compilerOptions": {"paths": {"@utils/*": ["src/utils/*"]}}})
        r = parse_json(src, "tsconfig.json")
        self.assertIn("typescript-config", r["tags"])


class TestShellParser(unittest.TestCase):

    def test_source_import(self):
        src = "source ./lib/helpers.sh\n"
        r = parse_shell(src)
        self.assertEqual(r["imports"][0].type, "source")
        self.assertIn("./lib/helpers.sh", r["imports"][0].source)

    def test_env_var_export(self):
        src = "export DATABASE_URL=postgres://localhost\n"
        r = parse_shell(src)
        names = [e.name for e in r["exports"]]
        self.assertIn("DATABASE_URL", names)

    def test_function_def(self):
        src = "function setup() {\n  echo hi\n}\n"
        r = parse_shell(src)
        self.assertIn("setup", [d.name for d in r["definitions"]])

    def test_docker_tag(self):
        src = "docker build -t myimage .\n"
        r = parse_shell(src)
        self.assertIn("docker", r["tags"])


# ═══════════════════════════════════════════════════════════════════════════════
# Walker tests
# ═══════════════════════════════════════════════════════════════════════════════

class TestWalker(unittest.TestCase):

    def test_basic_walk(self):
        with _tmp_project(
            ("main.py", "# main"),
            ("utils/helpers.py", "# helpers"),
        ) as tmp:
            files = walk_directory(tmp)
            rel_paths = [f.relative_path for f in files]
            self.assertIn("main.py", rel_paths)
            self.assertIn("utils/helpers.py", rel_paths)

    def test_node_modules_ignored(self):
        with _tmp_project(
            ("index.js", ""),
            ("node_modules/express/index.js", ""),
        ) as tmp:
            files = walk_directory(tmp)
            paths = [f.relative_path for f in files]
            self.assertIn("index.js", paths)
            self.assertFalse(any("node_modules" in p for p in paths))

    def test_pycache_ignored(self):
        with _tmp_project(
            ("app.py", ""),
            ("__pycache__/app.cpython-311.pyc", ""),
        ) as tmp:
            files = walk_directory(tmp)
            paths = [f.relative_path for f in files]
            self.assertFalse(any("__pycache__" in p for p in paths))

    def test_extra_ignore(self):
        with _tmp_project(
            ("src/main.py", ""),
            ("dist/bundle.js", ""),
        ) as tmp:
            files = walk_directory(tmp, extra_ignore=["dist"])
            paths = [f.relative_path for f in files]
            self.assertFalse(any("dist" in p for p in paths))

    def test_make_node_id(self):
        self.assertEqual(make_node_id("src/utils/helpers.py"), "src_utils_helpers_py")
        self.assertEqual(make_node_id("main.py"), "main_py")

    def test_hidden_files_ignored(self):
        with _tmp_project(
            ("visible.py", ""),
            (".hidden.py", ""),
        ) as tmp:
            files = walk_directory(tmp)
            paths = [f.relative_path for f in files]
            self.assertIn("visible.py", paths)
            self.assertNotIn(".hidden.py", paths)


# ═══════════════════════════════════════════════════════════════════════════════
# Project config tests
# ═══════════════════════════════════════════════════════════════════════════════

class TestProjectConfig(unittest.TestCase):

    def test_bump_patch(self):
        self.assertEqual(bump_version("1.2.3", "patch"), "1.2.4")

    def test_bump_minor(self):
        self.assertEqual(bump_version("1.2.3", "minor"), "1.3.0")

    def test_bump_major(self):
        self.assertEqual(bump_version("1.2.3", "major"), "2.0.0")

    def test_bump_defaults_patch(self):
        self.assertEqual(bump_version("0.0.1"), "0.0.2")

    def test_init_creates_config(self):
        with tempfile.TemporaryDirectory() as tmp:
            config = init_project_config(tmp)
            self.assertTrue(os.path.exists(os.path.join(tmp, "side.project.json")))
            self.assertEqual(config["name"], os.path.basename(tmp))

    def test_load_missing_returns_defaults(self):
        with tempfile.TemporaryDirectory() as tmp:
            config = load_project_config(tmp)
            self.assertFalse(config["_exists"])
            self.assertIn("versions", config)

    def test_save_and_reload(self):
        with tempfile.TemporaryDirectory() as tmp:
            config = init_project_config(tmp)
            config["version"] = "9.9.9"
            save_project_config(tmp, config)
            reloaded = load_project_config(tmp)
            self.assertEqual(reloaded["version"], "9.9.9")

    def test_no_internal_keys_saved(self):
        with tempfile.TemporaryDirectory() as tmp:
            config = init_project_config(tmp)
            config_path = os.path.join(tmp, "side.project.json")
            with open(config_path) as f:
                raw = json.load(f)
            for key in raw:
                self.assertFalse(key.startswith("_"), f"Internal key found: {key}")


# ═══════════════════════════════════════════════════════════════════════════════
# Edge resolver tests
# ═══════════════════════════════════════════════════════════════════════════════

class TestResolveEdges(unittest.TestCase):

    def _make_node(self, rel_path: str, imports=None) -> FileNode:
        return FileNode(
            id=make_node_id(rel_path),
            label=os.path.basename(rel_path),
            path=rel_path,
            full_path=f"/proj/{rel_path}",
            category="python",
            ext=".py",
            imports=imports or [],
        )

    def test_resolves_relative_import(self):
        main = self._make_node("main.py", [
            ImportRecord(type="from-import", source="utils", names=["helper"])
        ])
        utils = self._make_node("utils.py")
        file_index = {"main.py": main.id, "utils.py": utils.id}
        edges = resolve_edges([main, utils], file_index, "/proj")
        self.assertTrue(any(e.source == main.id and e.target == utils.id for e in edges))

    def test_external_package(self):
        node = self._make_node("app.py", [
            ImportRecord(type="import", source="requests")
        ])
        file_index = {"app.py": node.id}
        edges = resolve_edges([node], file_index, "/proj")
        ext_edges = [e for e in edges if e.is_external]
        self.assertTrue(len(ext_edges) > 0)
        self.assertEqual(ext_edges[0].external_pkg, "requests")

    def test_no_duplicate_edges(self):
        main = self._make_node("main.py", [
            ImportRecord(type="from-import", source="utils", names=["a"]),
            ImportRecord(type="from-import", source="utils", names=["b"]),
        ])
        utils = self._make_node("utils.py")
        file_index = {"main.py": main.id, "utils.py": utils.id}
        edges = resolve_edges([main, utils], file_index, "/proj")
        internal = [e for e in edges if not e.is_external]
        self.assertEqual(len(internal), 1)

    def test_collect_external_packages(self):
        node = self._make_node("a.py", [ImportRecord(type="import", source="numpy")])
        file_index = {"a.py": node.id}
        edges = resolve_edges([node], file_index, "/proj")
        pkgs = collect_external_packages(edges)
        self.assertEqual(pkgs[0]["name"], "numpy")


# ═══════════════════════════════════════════════════════════════════════════════
# Layout tests
# ═══════════════════════════════════════════════════════════════════════════════

class TestLayout(unittest.TestCase):

    def _node(self, nid: str) -> FileNode:
        return FileNode(id=nid, label=nid, path=f"{nid}.py", full_path=f"/p/{nid}.py",
                        category="python", ext=".py")

    def test_all_nodes_get_positions(self):
        nodes = [self._node("a"), self._node("b"), self._node("c")]
        edges = [Edge(id="e0", source="a", target="b", type="import")]
        assign_positions(nodes, edges)
        for n in nodes:
            self.assertIsNotNone(n.position, f"{n.id} has no position")

    def test_root_at_zero(self):
        nodes = [self._node("root"), self._node("child")]
        edges = [Edge(id="e0", source="root", target="child", type="import")]
        assign_positions(nodes, edges)
        root = next(n for n in nodes if n.id == "root")
        child = next(n for n in nodes if n.id == "child")
        self.assertEqual(root.position.x, 0.0)
        self.assertGreater(child.position.x, root.position.x)

    def test_empty_graph(self):
        assign_positions([], [])   # should not raise


# ═══════════════════════════════════════════════════════════════════════════════
# Doc check tests
# ═══════════════════════════════════════════════════════════════════════════════

class TestDocCheck(unittest.TestCase):

    def _node(self, path: str, **kwargs) -> FileNode:
        return FileNode(
            id=make_node_id(path), label=os.path.basename(path),
            path=path, full_path=f"/p/{path}",
            category=kwargs.get("category", "python"), ext=kwargs.get("ext", ".py"),
            imports=kwargs.get("imports", []),
            exports=kwargs.get("exports", []),
            definitions=kwargs.get("definitions", []),
        )

    def test_missing_readme_warning(self):
        nodes = [self._node("src/main.py")]
        audit = audit_docs("/p", nodes)
        types = [w.type for w in audit.warnings]
        self.assertIn("missing-readme", types)

    def test_healthy_with_readme(self):
        from graph.types import ExportRecord, Definition
        src_node = self._node("src/main.py",
                               exports=[ExportRecord(type="implicit", name="main", kind="function")],
                               definitions=[Definition(name="main", kind="function", line=1)])
        readme = self._node("src/README.md", category="docs", ext=".md")
        audit = audit_docs("/p", [src_node, readme])
        missing = [w for w in audit.warnings if w.type == "missing-readme"]
        self.assertEqual(len(missing), 0)


# ═══════════════════════════════════════════════════════════════════════════════
# Full pipeline test
# ═══════════════════════════════════════════════════════════════════════════════

class TestProjectParser(unittest.TestCase):

    def test_parse_synthetic_project(self):
        with _tmp_project(
            ("main.py", "from utils.helpers import greet\n\nif __name__ == '__main__':\n    greet('world')\n"),
            ("utils/__init__.py", ""),
            ("utils/helpers.py", "def greet(name):\n    print(f'Hello, {name}')\n"),
            ("README.md", "# Test project\n"),
        ) as tmp:
            graph = parse_project(tmp)
            d = graph.to_dict()

            self.assertGreaterEqual(d["meta"]["totalFiles"], 3)
            node_paths = [n["path"] for n in d["nodes"]]
            self.assertIn("main.py", node_paths)
            self.assertIn("utils/helpers.py", node_paths)

            # main.py should have an edge to utils/helpers.py
            edges = d["edges"]
            main_id = make_node_id("main.py")
            helpers_id = make_node_id("utils/helpers.py")
            internal = [e for e in edges if not e.get("isExternal")]
            found = any(e["source"] == main_id and e["target"] == helpers_id for e in internal)
            self.assertTrue(found, "Expected edge main.py → utils/helpers.py")

    def test_parse_returns_positions(self):
        with _tmp_project(("app.py", "import os\n")) as tmp:
            graph = parse_project(tmp)
            for node in graph.nodes:
                self.assertIsNotNone(node.position, f"{node.path} missing position")

    def test_graph_serialises_to_json(self):
        with _tmp_project(("hello.py", "print('hi')\n")) as tmp:
            graph = parse_project(tmp)
            # Should not raise
            txt = json.dumps(graph.to_dict())
            self.assertIn("nodes", txt)


# ═══════════════════════════════════════════════════════════════════════════════
# Version manager tests
# ═══════════════════════════════════════════════════════════════════════════════

class TestVersionManager(unittest.TestCase):

    def _make_project(self, tmp_dir: str) -> None:
        os.makedirs(os.path.join(tmp_dir, "src"), exist_ok=True)
        with open(os.path.join(tmp_dir, "main.py"), "w") as f:
            f.write("print('hello')\n")
        with open(os.path.join(tmp_dir, "src", "utils.py"), "w") as f:
            f.write("def helper(): pass\n")
        cfg = {"name": "testproj", "version": "1.0.0",
               "versions": {"dir": "versions", "compress": True, "keep": 5}}
        with open(os.path.join(tmp_dir, "side.project.json"), "w") as f:
            json.dump(cfg, f)

    def test_archive_creates_tarball(self):
        with tempfile.TemporaryDirectory() as tmp:
            self._make_project(tmp)
            path = archive_version(tmp)
            self.assertTrue(os.path.exists(path))
            self.assertTrue(path.endswith(".tar.gz"))

    def test_archive_is_valid_tar(self):
        with tempfile.TemporaryDirectory() as tmp:
            self._make_project(tmp)
            path = archive_version(tmp)
            self.assertTrue(tarfile.is_tarfile(path))

    def test_list_versions(self):
        with tempfile.TemporaryDirectory() as tmp:
            self._make_project(tmp)
            archive_version(tmp)
            versions = list_versions(tmp)
            self.assertEqual(len(versions), 1)
            self.assertEqual(versions[0]["type"], "tarball")

    def test_apply_update(self):
        with tempfile.TemporaryDirectory() as proj_dir:
            self._make_project(proj_dir)

            # Build an "update" tarball from a temp dir
            with tempfile.TemporaryDirectory() as update_src:
                os.makedirs(os.path.join(update_src, "testproj"))
                with open(os.path.join(update_src, "testproj", "new_file.py"), "w") as f:
                    f.write("# new!\n")
                tarball = os.path.join(update_src, "update.tar.gz")
                with tarfile.open(tarball, "w:gz") as tar:
                    tar.add(os.path.join(update_src, "testproj"), arcname="testproj")

                new_ver, arch = apply_update(proj_dir, tarball, "minor")
                self.assertEqual(new_ver, "1.1.0")
                self.assertTrue(os.path.exists(arch))
                self.assertTrue(os.path.exists(os.path.join(proj_dir, "new_file.py")))

    def test_versions_dir_excluded_from_archive(self):
        with tempfile.TemporaryDirectory() as tmp:
            self._make_project(tmp)
            archive_version(tmp)  # creates versions/
            path = archive_version(tmp)  # second archive
            with tarfile.open(path, "r:gz") as tar:
                names = tar.getnames()
            self.assertFalse(any("versions" in n for n in names))


# ═══════════════════════════════════════════════════════════════════════════════
# Process manager tests
# ═══════════════════════════════════════════════════════════════════════════════

class TestProcessManager(unittest.TestCase):

    def test_start_and_exit(self):
        mgr = ProcessManager()
        proc = mgr.start(name="echo", command="echo hello")
        time.sleep(0.5)
        info = proc.info()
        self.assertIn(info["status"], ("stopped", "crashed", "running"))

    def test_logs_captured(self):
        mgr = ProcessManager()
        proc = mgr.start(name="echo", command="echo captured_line")
        time.sleep(0.5)
        logs = proc.logs()
        lines = [entry["line"] for entry in logs]
        self.assertTrue(any("captured_line" in l for l in lines))

    def test_stop(self):
        mgr = ProcessManager()
        # Use a long-running process
        proc = mgr.start(name="sleep", command="sleep 30")
        time.sleep(0.2)
        ok = mgr.stop(proc.id)
        self.assertTrue(ok)

    def test_list(self):
        mgr = ProcessManager()
        mgr.start(name="p1", command="echo a")
        mgr.start(name="p2", command="echo b")
        time.sleep(0.3)
        listing = mgr.list()
        self.assertEqual(len(listing), 2)

    def test_on_stdout_callback(self):
        received = []
        mgr = ProcessManager()
        proc = mgr.start(name="cb-test", command="echo callback_works")
        proc.on_stdout(received.append)
        time.sleep(0.5)
        # Callback may fire after attachment; check logs as fallback
        logs = [e["line"] for e in proc.logs()]
        self.assertTrue(
            any("callback_works" in l for l in logs),
            "Expected output not found in logs"
        )

    def test_purge_stopped(self):
        mgr = ProcessManager()
        mgr.start(name="quick", command="echo done")
        time.sleep(0.5)
        removed = mgr.purge_stopped()
        self.assertGreaterEqual(removed, 0)


# ── Runner ────────────────────────────────────────────────────────────────────

# ── runner below ──


# ═══════════════════════════════════════════════════════════════════════════════
# Monitor tests
# ═══════════════════════════════════════════════════════════════════════════════

class TestParseTimer(unittest.TestCase):

    def test_stages_recorded(self):
        from monitor.perf import ParseTimer
        t = ParseTimer()
        with t.stage("walk"):
            pass
        with t.stage("parse"):
            time.sleep(0.01)
        report = t.report()
        names = [s["name"] for s in report["stages"]]
        self.assertIn("walk", names)
        self.assertIn("parse", names)

    def test_total_ms_positive(self):
        from monitor.perf import ParseTimer
        t = ParseTimer()
        with t.stage("x"):
            time.sleep(0.005)
        self.assertGreater(t.total_ms(), 0)

    def test_slowest_identified(self):
        from monitor.perf import ParseTimer
        t = ParseTimer()
        with t.stage("fast"):
            pass
        with t.stage("slow"):
            time.sleep(0.02)
        report = t.report()
        self.assertEqual(report["slowest"], "slow")

    def test_perf_embedded_in_graph(self):
        """parse_project stores per-stage timing in graph.meta.perf."""
        from parser.project_parser import parse_project
        with _tmp_project(("main.py", "import os\n")) as tmp:
            graph = parse_project(tmp, save_json=False)
        # perf lives in GraphMeta now, not as a private attribute
        perf = graph.meta.perf
        self.assertIn("stages", perf)
        self.assertIn("total_ms", perf)
        stage_names = [s["name"] for s in perf["stages"]]
        self.assertIn("parse_files", stage_names)
        self.assertIn("walk", stage_names)

    def test_nodegraph_json_written(self):
        """parse_project auto-saves .nodegraph.json."""
        import json
        from parser.project_parser import parse_project
        with _tmp_project(("app.py", "def main(): pass\n")) as tmp:
            parse_project(tmp)
            json_path = os.path.join(tmp, ".nodegraph.json")
            self.assertTrue(os.path.isfile(json_path))
            data = json.load(open(json_path))
            self.assertIn("nodes", data)
            self.assertIn("edges", data)


# ═══════════════════════════════════════════════════════════════════════════════
# Build — Cleaner tests
# ═══════════════════════════════════════════════════════════════════════════════

class TestCleaner(unittest.TestCase):

    def test_dry_run_removes_nothing(self):
        from build.cleaner import clean_project, CleanOptions
        with _tmp_project(
            ("__pycache__/foo.pyc", ""),
            ("main.py", "pass\n"),
        ) as tmp:
            opts = CleanOptions(tiers=["cache"], dry_run=True)
            report = clean_project(tmp, opts)
            self.assertTrue(len(report.removed) > 0)
            # File should still exist — dry run
            self.assertTrue(os.path.exists(os.path.join(tmp, "__pycache__")))

    def test_cache_tier_removes_pycache(self):
        from build.cleaner import clean_project, CleanOptions
        with _tmp_project(
            ("__pycache__/module.pyc", "bytecode"),
            ("main.py", "pass\n"),
        ) as tmp:
            opts = CleanOptions(tiers=["cache"])
            report = clean_project(tmp, opts)
            self.assertFalse(os.path.exists(os.path.join(tmp, "__pycache__")))
            self.assertTrue(any("__pycache__" in r for r in report.removed))

    def test_logs_tier_removes_log_files(self):
        from build.cleaner import clean_project, CleanOptions
        with _tmp_project(
            ("app.log", "log content"),
            ("main.py", "pass\n"),
        ) as tmp:
            opts = CleanOptions(tiers=["logs"])
            report = clean_project(tmp, opts)
            self.assertFalse(os.path.exists(os.path.join(tmp, "app.log")))

    def test_protect_prevents_deletion(self):
        from build.cleaner import clean_project, CleanOptions
        with _tmp_project(
            ("logs/keep.log", "important"),
            ("main.py", "pass\n"),
        ) as tmp:
            opts = CleanOptions(tiers=["logs"], protect=["logs"])
            report = clean_project(tmp, opts)
            self.assertTrue(os.path.exists(os.path.join(tmp, "logs", "keep.log")))

    def test_freed_bytes_nonzero(self):
        from build.cleaner import clean_project, CleanOptions
        with _tmp_project(
            ("junk.log", "x" * 500),
            ("main.py", "pass\n"),
        ) as tmp:
            opts = CleanOptions(tiers=["logs"])
            report = clean_project(tmp, opts)
            self.assertGreater(report.freed_bytes, 0)


# ═══════════════════════════════════════════════════════════════════════════════
# Build — Minifier tests
# ═══════════════════════════════════════════════════════════════════════════════

class TestMinifier(unittest.TestCase):

    def test_strips_python_comments(self):
        from build.minifier import minify_file, MinifyOptions
        with _tmp_project(("util.py", "# this is a comment\ndef foo(): pass\n")) as tmp:
            path = os.path.join(tmp, "util.py")
            result = minify_file(path, MinifyOptions(strip_comments=True))
            self.assertNotIn("# this is a comment", result)
            self.assertIn("def foo", result)

    def test_strips_docstring(self):
        from build.minifier import minify_file, MinifyOptions
        src = '"""Module docstring."""\ndef foo():\n    """Func doc."""\n    return 1\n'
        with _tmp_project(("m.py", src)) as tmp:
            path = os.path.join(tmp, "m.py")
            result = minify_file(path, MinifyOptions(strip_docstrings=True))
            self.assertNotIn("Module docstring", result)
            self.assertNotIn("Func doc", result)
            self.assertIn("def foo", result)

    def test_preserves_noqa_regex_path(self):
        # ast.unparse discards all comments (including noqa) by design.
        # The regex path (strip_docstrings=False) preserves # noqa.
        from build.minifier import _minify_python, MinifyOptions
        src = "import os  # noqa: F401\n"
        opts = MinifyOptions(strip_docstrings=False, strip_comments=True)
        result = _minify_python(src, opts)
        # noqa comment should survive the regex comment stripper
        self.assertIn("noqa", result)

    def test_strips_regular_comment_via_regex(self):
        from build.minifier import _minify_python, MinifyOptions
        src = "x = 1  # regular comment\n"
        opts = MinifyOptions(strip_docstrings=False, strip_comments=True)
        result = _minify_python(src, opts)
        self.assertNotIn("regular comment", result)
        self.assertIn("x = 1", result)

    def test_minify_json(self):
        from build.minifier import minify_file, MinifyOptions
        src = '{\n  "key": "value",\n  "num": 42\n}\n'
        with _tmp_project(("config.json", src)) as tmp:
            path = os.path.join(tmp, "config.json")
            result = minify_file(path, MinifyOptions(minify_json=True))
            self.assertNotIn("\n  ", result)
            self.assertIn('"key"', result)

    def test_minify_project_produces_output(self):
        from build.minifier import minify_project, MinifyOptions
        with _tmp_project(
            ("main.py", "# comment\ndef run(): pass\n"),
            ("utils.py", "def helper(): return 1\n"),
        ) as tmp:
            import tempfile
            with tempfile.TemporaryDirectory() as out:
                report = minify_project(tmp, out, MinifyOptions())
                self.assertGreater(report.files_processed, 0)
                self.assertTrue(os.path.exists(os.path.join(out, "main.py")))

    def test_binary_raises(self):
        from build.minifier import minify_file
        with _tmp_project(("img.png", b"\x89PNG\r\n".decode("latin1"))) as tmp:
            with self.assertRaises(ValueError):
                minify_file(os.path.join(tmp, "img.png"))


# ═══════════════════════════════════════════════════════════════════════════════
# Build — Packager tests
# ═══════════════════════════════════════════════════════════════════════════════

class TestPackager(unittest.TestCase):

    def _make_project(self, tmp):
        import json
        with open(os.path.join(tmp, "main.py"), "w") as f:
            f.write("print('hello')\n")
        with open(os.path.join(tmp, "side.project.json"), "w") as f:
            json.dump({"name": "testapp", "version": "1.0.0",
                       "versions": {"dir": "versions", "compress": True, "keep": 5}}, f)

    def test_tarball_created(self):
        from build.packager import package_project, PackageOptions
        with tempfile.TemporaryDirectory() as tmp:
            self._make_project(tmp)
            with tempfile.TemporaryDirectory() as out:
                opts = PackageOptions(kind="tarball", minify=False, clean=False)
                result = package_project(tmp, out, opts)
                self.assertTrue(os.path.isfile(result.archive_path))
                self.assertTrue(result.archive_path.endswith(".tar.gz"))

    def test_portable_creates_directory(self):
        from build.packager import package_project, PackageOptions
        with tempfile.TemporaryDirectory() as tmp:
            self._make_project(tmp)
            with tempfile.TemporaryDirectory() as out:
                opts = PackageOptions(kind="portable", minify=False, clean=False)
                result = package_project(tmp, out, opts)
                self.assertTrue(os.path.isdir(result.output_path))
                self.assertTrue(os.path.isfile(
                    os.path.join(result.output_path, "build-manifest.json")))

    def test_manifest_recorded(self):
        import json
        from build.packager import package_project, PackageOptions
        with tempfile.TemporaryDirectory() as tmp:
            self._make_project(tmp)
            with tempfile.TemporaryDirectory() as out:
                opts = PackageOptions(kind="tarball", minify=False, clean=False)
                package_project(tmp, out, opts)
                manifest = json.load(open(os.path.join(out, "build-manifest.json")))
                self.assertIn("history", manifest)
                self.assertEqual(manifest["history"][0]["name"], "testapp")

    def test_build_with_minify(self):
        from build.packager import package_project, PackageOptions
        with tempfile.TemporaryDirectory() as tmp:
            with open(os.path.join(tmp, "main.py"), "w") as f:
                f.write("# this is a dev comment\ndef run(): pass\n")
            with tempfile.TemporaryDirectory() as out:
                opts = PackageOptions(kind="tarball", minify=True, clean=False)
                result = package_project(tmp, out, opts)
                # Should succeed even without side.project.json
                self.assertTrue(os.path.isfile(result.archive_path))





# ═══════════════════════════════════════════════════════════════════════════════
# TOML / YAML parser tests
# ═══════════════════════════════════════════════════════════════════════════════

class TestTomlParser(unittest.TestCase):

    def test_pyproject_name_and_deps(self):
        from parser.parsers.toml_yaml_parser import parse_toml
        src = '[project]\nname = "myapp"\nversion = "1.0.0"\ndependencies = ["requests>=2.0", "flask"]\n'
        r = parse_toml(src, "pyproject.toml")
        self.assertIn("pyproject", r["tags"])
        self.assertTrue(any("pkg:myapp" in t for t in r["tags"]))
        sources = [i.source for i in r["imports"]]
        self.assertIn("requests", sources)
        self.assertIn("flask", sources)

    def test_cargo_toml_deps(self):
        from parser.parsers.toml_yaml_parser import parse_toml
        src = '[package]\nname = "mylib"\nversion = "0.1.0"\n\n[dependencies]\nserde = "1.0"\ntokio = { version = "1", features = ["full"] }\n'
        r = parse_toml(src, "Cargo.toml")
        self.assertIn("cargo", r["tags"])
        sources = [i.source for i in r["imports"]]
        self.assertIn("serde", sources)
        self.assertIn("tokio", sources)

    def test_generic_toml_keys(self):
        from parser.parsers.toml_yaml_parser import parse_toml
        src = '[database]\nhost = "localhost"\nport = 5432\n'
        r = parse_toml(src, "config.toml")
        names = [d.name for d in r["definitions"]]
        self.assertIn("database", names)

    def test_pyproject_tool_detection(self):
        from parser.parsers.toml_yaml_parser import parse_toml
        src = '[tool.pytest.ini_options]\ntestpaths = ["tests"]\n[tool.black]\nline-length = 88\n'
        r = parse_toml(src, "pyproject.toml")
        self.assertTrue(any("tool:pytest" in t for t in r["tags"]))
        self.assertTrue(any("tool:black" in t for t in r["tags"]))


class TestYamlParser(unittest.TestCase):

    def test_docker_compose_services(self):
        from parser.parsers.toml_yaml_parser import parse_yaml
        src = 'version: "3"\nservices:\n  web:\n    image: nginx:latest\n  db:\n    image: postgres:15\n'
        r = parse_yaml(src, "docker-compose.yml")
        self.assertIn("docker-compose", r["tags"])
        service_names = [d.name for d in r["definitions"]]
        self.assertIn("web", service_names)
        self.assertIn("db", service_names)
        images = [i.source for i in r["imports"]]
        self.assertIn("nginx", images)
        self.assertIn("postgres", images)

    def test_github_workflow_jobs(self):
        from parser.parsers.toml_yaml_parser import parse_yaml
        src = 'name: CI\non: push\njobs:\n  test:\n    runs-on: ubuntu-latest\n  build:\n    runs-on: ubuntu-latest\n'
        r = parse_yaml(src, ".github/workflows/ci.yml")
        self.assertIn("github-actions", r["tags"])
        job_names = [d.name for d in r["definitions"]]
        self.assertIn("test", job_names)
        self.assertIn("build", job_names)

    def test_generic_yaml_keys(self):
        from parser.parsers.toml_yaml_parser import parse_yaml
        src = 'server:\n  host: localhost\n  port: 8080\ndatabase:\n  url: postgres://\n'
        r = parse_yaml(src, "config.yaml")
        names = [d.name for d in r["definitions"]]
        self.assertIn("server", names)
        self.assertIn("database", names)

    def test_toml_in_parsers_dispatch(self):
        from parser.parsers import PARSERS
        self.assertIn(".toml", PARSERS)
        self.assertIn(".yaml", PARSERS)
        self.assertIn(".yml", PARSERS)

    def test_pyproject_parsed_in_full_pipeline(self):
        """pyproject.toml dependencies appear as external edges in the graph."""
        import json
        from parser.project_parser import parse_project
        pyproject_src = '[project]\nname = "testpkg"\nversion = "0.1.0"\ndependencies = ["requests"]\n'
        with _tmp_project(
            ("pyproject.toml", pyproject_src),
            ("main.py", "import requests\n"),
        ) as tmp:
            graph = parse_project(tmp, save_json=False)
            # pyproject.toml should have a node
            paths = [n.path for n in graph.nodes]
            self.assertIn("pyproject.toml", paths)
            # requests dep node from pyproject.toml
            pyproject_node = next(n for n in graph.nodes if n.path == "pyproject.toml")
            dep_sources = [i.source for i in pyproject_node.imports]
            self.assertIn("requests", dep_sources)


# ═══════════════════════════════════════════════════════════════════════════════
# Version manager bootstrap tests
# ═══════════════════════════════════════════════════════════════════════════════

class TestVersionManagerBootstrap(unittest.TestCase):

    def test_archive_creates_side_project_json(self):
        """archive_version auto-creates side.project.json on first run."""
        from version.version_manager import archive_version
        with tempfile.TemporaryDirectory() as tmp:
            # Brand new project — no side.project.json
            with open(os.path.join(tmp, "main.py"), "w") as f:
                f.write("print('hello')\n")
            path = archive_version(tmp)
            self.assertTrue(os.path.isfile(path))
            cfg_path = os.path.join(tmp, "side.project.json")
            self.assertTrue(os.path.isfile(cfg_path),
                            "side.project.json should be created by archive_version")

    def test_archive_preserves_existing_version(self):
        """archive_version doesn't overwrite an existing side.project.json."""
        import json
        from version.version_manager import archive_version
        with tempfile.TemporaryDirectory() as tmp:
            cfg = {"name": "mypkg", "version": "3.7.2",
                   "versions": {"dir": "versions", "compress": True, "keep": 5}}
            with open(os.path.join(tmp, "side.project.json"), "w") as f:
                json.dump(cfg, f)
            with open(os.path.join(tmp, "app.py"), "w") as f:
                f.write("pass\n")
            archive_version(tmp)
            cfg_after = json.load(open(os.path.join(tmp, "side.project.json")))
            self.assertEqual(cfg_after["version"], "3.7.2")




# ═══════════════════════════════════════════════════════════════════════════════
# Monitor — instrument + MetricsWatcher tests
# ═══════════════════════════════════════════════════════════════════════════════

class TestInstrument(unittest.TestCase):

    def setUp(self):
        # Reset instrument state between tests
        from monitor import instrument
        instrument.reset()
        instrument._project_root = ""
        instrument._metrics_path = ""

    def test_timed_decorator_records(self):
        from monitor.instrument import timed, get_snapshot
        import tempfile, os

        @timed
        def add(a, b):
            return a + b

        with tempfile.TemporaryDirectory() as tmp:
            from monitor.instrument import init
            # Patch __file__ on the wrapper via module inspection
            import monitor.instrument as inst
            inst._project_root = tmp
            inst._metrics_path = os.path.join(tmp, ".side-metrics.json")

            add(1, 2)
            add(3, 4)

            snap = get_snapshot()
            # At least one file entry should exist
            self.assertGreater(len(snap["files"]), 0)
            total_calls = sum(v["calls"] for v in snap["files"].values())
            self.assertGreaterEqual(total_calls, 2)

    def test_timed_block_records(self):
        from monitor.instrument import timed_block, get_snapshot, init
        import tempfile, os

        with tempfile.TemporaryDirectory() as tmp:
            init(tmp)
            with timed_block("test_block", os.path.join(tmp, "fake.py")):
                time.sleep(0.01)
            snap = get_snapshot()
            fn_keys = list(snap["functions"].keys())
            self.assertTrue(any("test_block" in k for k in fn_keys))
            # Should have recorded > 0ms
            for k, v in snap["functions"].items():
                if "test_block" in k:
                    self.assertGreater(v["avg_ms"], 0)

    def test_flush_writes_file(self):
        from monitor.instrument import init, flush, timed_block
        import tempfile, os, json

        with tempfile.TemporaryDirectory() as tmp:
            init(tmp, flush_interval=999)   # disable auto-flush
            with timed_block("x", os.path.join(tmp, "m.py")):
                pass
            flush()
            metrics_path = os.path.join(tmp, ".side-metrics.json")
            self.assertTrue(os.path.isfile(metrics_path))
            data = json.load(open(metrics_path))
            self.assertIn("files", data)
            self.assertIn("functions", data)
            self.assertIn("pid", data)

    def test_reset_clears_data(self):
        from monitor.instrument import timed_block, get_snapshot, reset, init
        import tempfile, os

        with tempfile.TemporaryDirectory() as tmp:
            init(tmp)
            with timed_block("work", os.path.join(tmp, "a.py")):
                pass
            self.assertGreater(len(get_snapshot()["files"]), 0)
            reset()
            snap = get_snapshot()
            self.assertEqual(len(snap["files"]), 0)
            self.assertEqual(len(snap["functions"]), 0)

    def test_stats_accumulate_correctly(self):
        from monitor.instrument import timed_block, get_snapshot, reset, init
        import tempfile, os

        with tempfile.TemporaryDirectory() as tmp:
            init(tmp)
            fp = os.path.join(tmp, "worker.py")
            for _ in range(5):
                with timed_block("step", fp):
                    time.sleep(0.002)
            snap = get_snapshot()
            fn_key = next(k for k in snap["functions"] if "step" in k)
            stats = snap["functions"][fn_key]
            self.assertEqual(stats["calls"], 5)
            self.assertGreater(stats["avg_ms"], 0)
            self.assertGreaterEqual(stats["max_ms"], stats["avg_ms"])

    def test_init_sets_paths(self):
        from monitor import instrument
        import tempfile, os
        with tempfile.TemporaryDirectory() as tmp:
            instrument.init(tmp)
            self.assertEqual(os.path.abspath(instrument._project_root),
                             os.path.abspath(tmp))
            self.assertTrue(instrument._metrics_path.endswith(".side-metrics.json"))


class TestMetricsWatcher(unittest.TestCase):

    def _write_metrics(self, path: str, data: dict):
        import json
        with open(path, "w") as f:
            json.dump(data, f)

    def test_reads_metrics_file(self):
        from monitor.perf import MetricsWatcher
        import tempfile, os

        with tempfile.TemporaryDirectory() as tmp:
            metrics_path = os.path.join(tmp, ".side-metrics.json")
            self._write_metrics(metrics_path, {
                "pid": 1234,
                "updated": time.time(),
                "files": {
                    "src/main.py": {"calls": 10, "avg_ms": 5.0, "max_ms": 12.0,
                                    "last_ms": 4.8, "last_ts": time.time(), "total_ms": 50.0}
                },
                "functions": {}
            })

            watcher = MetricsWatcher(tmp)
            # Force a poll without starting the thread
            watcher._poll()

            fm = watcher.get_file_metrics()
            self.assertIn("src/main.py", fm)
            self.assertEqual(fm["src/main.py"]["calls"], 10)

    def test_is_active_with_fresh_data(self):
        from monitor.perf import MetricsWatcher
        import tempfile, os

        with tempfile.TemporaryDirectory() as tmp:
            metrics_path = os.path.join(tmp, ".side-metrics.json")
            self._write_metrics(metrics_path, {
                "pid": 1,
                "updated": time.time(),   # just now
                "files": {}, "functions": {}
            })
            watcher = MetricsWatcher(tmp)
            watcher._poll()
            self.assertTrue(watcher.is_active())

    def test_is_not_active_with_stale_data(self):
        from monitor.perf import MetricsWatcher
        import tempfile, os

        with tempfile.TemporaryDirectory() as tmp:
            metrics_path = os.path.join(tmp, ".side-metrics.json")
            self._write_metrics(metrics_path, {
                "pid": 1,
                "updated": time.time() - 60,   # 60s ago = stale
                "files": {}, "functions": {}
            })
            watcher = MetricsWatcher(tmp)
            watcher._poll()
            self.assertFalse(watcher.is_active())

    def test_skips_reread_if_mtime_unchanged(self):
        from monitor.perf import MetricsWatcher
        import tempfile, os

        with tempfile.TemporaryDirectory() as tmp:
            metrics_path = os.path.join(tmp, ".side-metrics.json")
            self._write_metrics(metrics_path, {
                "pid": 1, "updated": time.time(),
                "files": {"a.py": {"calls": 1, "avg_ms": 1.0, "max_ms": 1.0,
                                    "last_ms": 1.0, "last_ts": time.time(), "total_ms": 1.0}},
                "functions": {}
            })
            watcher = MetricsWatcher(tmp)
            watcher._poll()
            first = watcher.get_file_metrics()

            # Overwrite with different data but same mtime (simulate no change)
            watcher._mtime = os.path.getmtime(metrics_path) + 1  # pretend already read
            self._write_metrics(metrics_path, {
                "pid": 1, "updated": time.time(),
                "files": {"b.py": {"calls": 99, "avg_ms": 99.0, "max_ms": 99.0,
                                    "last_ms": 99.0, "last_ts": time.time(), "total_ms": 99.0}},
                "functions": {}
            })
            watcher._poll()   # mtime check will skip this read
            second = watcher.get_file_metrics()

            # Should still see original data (skipped the re-read)
            self.assertIn("a.py", second)

    def test_no_file_returns_empty(self):
        from monitor.perf import MetricsWatcher
        import tempfile

        with tempfile.TemporaryDirectory() as tmp:
            watcher = MetricsWatcher(tmp)   # no .side-metrics.json
            watcher._poll()
            self.assertEqual(watcher.get_file_metrics(), {})
            self.assertFalse(watcher.is_active())

    def test_thread_start_stop(self):
        from monitor.perf import MetricsWatcher
        import tempfile

        with tempfile.TemporaryDirectory() as tmp:
            watcher = MetricsWatcher(tmp)
            watcher.start()
            self.assertTrue(watcher._thread.is_alive())
            watcher.stop()
            watcher._thread.join(timeout=3)
            self.assertFalse(watcher._thread.is_alive())

    def test_function_metrics(self):
        from monitor.perf import MetricsWatcher
        import tempfile, os

        with tempfile.TemporaryDirectory() as tmp:
            metrics_path = os.path.join(tmp, ".side-metrics.json")
            self._write_metrics(metrics_path, {
                "pid": 1, "updated": time.time(),
                "files": {},
                "functions": {
                    "src/parser.py::parse_file": {
                        "calls": 5, "avg_ms": 20.0, "max_ms": 45.0,
                        "last_ms": 18.0, "last_ts": time.time(), "total_ms": 100.0
                    }
                }
            })
            watcher = MetricsWatcher(tmp)
            watcher._poll()
            fm = watcher.get_function_metrics()
            self.assertIn("src/parser.py::parse_file", fm)
            self.assertEqual(fm["src/parser.py::parse_file"]["calls"], 5)


# ── runner ──


# ═══════════════════════════════════════════════════════════════════════════════
# Instrumenter tests
# ═══════════════════════════════════════════════════════════════════════════════

class TestInstrumenter(unittest.TestCase):

    def _project(self, *files):
        """Create a temp project with given (path, content) files."""
        return _tmp_project(*files)

    def test_adds_timed_to_public_function(self):
        from monitor.instrumenter import Instrumenter, InstrumentOptions
        src = "def do_work(x):\n    return x * 2\n\ndef _private():\n    pass\n"
        with self._project(("worker.py", src)) as tmp:
            opts = InstrumentOptions(backup=False, preview=False)
            result = Instrumenter(tmp, opts).run()
            modified = open(os.path.join(tmp, "worker.py")).read()
            self.assertIn("@timed", modified)
            self.assertIn("from monitor.instrument import timed", modified)
            self.assertNotIn("_private", "".join(
                l for l in modified.splitlines() if "@timed" in l))

    def test_skips_private_functions(self):
        from monitor.instrumenter import Instrumenter, InstrumentOptions
        src = "def _helper():\n    pass\n\ndef _other():\n    pass\n"
        with self._project(("priv.py", src)) as tmp:
            opts = InstrumentOptions(backup=False)
            result = Instrumenter(tmp, opts).run()
            self.assertEqual(result.functions_timed, 0)

    def test_skips_already_instrumented(self):
        from monitor.instrumenter import Instrumenter, InstrumentOptions
        src = ("from monitor.instrument import timed\n\n"
               "@timed\ndef process():\n    return 1\n")
        with self._project(("mod.py", src)) as tmp:
            opts = InstrumentOptions(backup=False)
            result = Instrumenter(tmp, opts).run()
            self.assertEqual(result.functions_timed, 0)

    def test_preview_does_not_modify_files(self):
        from monitor.instrumenter import Instrumenter, InstrumentOptions
        src = "def compute(n):\n    return n ** 2\n"
        with self._project(("calc.py", src)) as tmp:
            opts = InstrumentOptions(backup=False, preview=True)
            result = Instrumenter(tmp, opts).run()
            # Preview flag — file should be unchanged
            unchanged = open(os.path.join(tmp, "calc.py")).read()
            self.assertEqual(unchanged, src)
            self.assertGreater(result.functions_timed, 0)

    def test_backup_creates_side_backup(self):
        from monitor.instrumenter import Instrumenter, InstrumentOptions
        src = "def run():\n    pass\n"
        with self._project(("app.py", src)) as tmp:
            opts = InstrumentOptions(backup=True, preview=False)
            result = Instrumenter(tmp, opts).run()
            backup_dir = os.path.join(tmp, ".side-backup")
            self.assertTrue(os.path.isdir(backup_dir))
            self.assertTrue(os.path.isfile(os.path.join(tmp, ".side-backup", "app.py")))

    def test_rollback_restores_original(self):
        from monitor.instrumenter import Instrumenter, InstrumentOptions, rollback
        src = "def compute():\n    return 42\n"
        with self._project(("mod.py", src)) as tmp:
            opts = InstrumentOptions(backup=True, preview=False)
            Instrumenter(tmp, opts).run()
            modified = open(os.path.join(tmp, "mod.py")).read()
            self.assertIn("@timed", modified)
            # Rollback
            result = rollback(tmp)
            restored = open(os.path.join(tmp, "mod.py")).read()
            self.assertEqual(restored, src)
            self.assertIn("mod.py", result["restored"])

    def test_generates_test_stubs(self):
        from monitor.instrumenter import Instrumenter, InstrumentOptions
        src = "def fetch_data(url):\n    return {}\n\ndef process(data):\n    return data\n"
        with self._project(("fetcher.py", src)) as tmp:
            opts = InstrumentOptions(backup=False, add_tests=True, test_dir="test")
            result = Instrumenter(tmp, opts).run()
            self.assertGreater(len(result.tests_created), 0)
            test_file = os.path.join(tmp, "test", "test_fetcher.py")
            self.assertTrue(os.path.isfile(test_file))
            test_content = open(test_file).read()
            self.assertIn("def test_fetch_data", test_content)
            self.assertIn("def test_process", test_content)

    def test_skips_test_files(self):
        from monitor.instrumenter import Instrumenter, InstrumentOptions
        src = "def test_something():\n    assert True\n"
        with self._project(("test_main.py", src)) as tmp:
            opts = InstrumentOptions(backup=False)
            result = Instrumenter(tmp, opts).run()
            # test_ file should be skipped
            self.assertIn("test_main.py", result.files_skipped)

    def test_result_parses_after_instrumentation(self):
        """Instrumented files must still be valid Python."""
        import ast
        from monitor.instrumenter import Instrumenter, InstrumentOptions
        src = ("import os\n\n"
               "def load(path):\n    return open(path).read()\n\n"
               "def save(path, data):\n    open(path, 'w').write(data)\n")
        with self._project(("io_utils.py", src)) as tmp:
            opts = InstrumentOptions(backup=False)
            Instrumenter(tmp, opts).run()
            modified = open(os.path.join(tmp, "io_utils.py")).read()
            # Must parse without error
            ast.parse(modified)

    def test_functions_timed_count(self):
        from monitor.instrumenter import Instrumenter, InstrumentOptions
        src = ("def a():\n    pass\n\n"
               "def b():\n    pass\n\n"
               "def c():\n    pass\n")
        with self._project(("multi.py", src)) as tmp:
            opts = InstrumentOptions(backup=False, min_lines=1)
            result = Instrumenter(tmp, opts).run()
            self.assertEqual(result.functions_timed, 3)


# ═══════════════════════════════════════════════════════════════════════════════
# Sandbox tests
# ═══════════════════════════════════════════════════════════════════════════════

class TestSandbox(unittest.TestCase):

    def _make_project(self, tmp):
        import json
        with open(os.path.join(tmp, "main.py"), "w") as f:
            f.write("print('sandbox ok')\n")
        with open(os.path.join(tmp, "app.log"), "w") as f:
            f.write("log line 1\n")
        with open(os.path.join(tmp, "side.project.json"), "w") as f:
            json.dump({"name": "sandtest", "version": "1.0.0",
                       "versions": {"dir": "versions", "compress": True, "keep": 5}}, f)

    def test_prepare_creates_temp_dir(self):
        from build.sandbox import SandboxRun, SandboxOptions
        with tempfile.TemporaryDirectory() as tmp:
            self._make_project(tmp)
            sb = SandboxRun(tmp, SandboxOptions(mode="clean"))
            tmp_dir = sb.prepare()
            self.assertTrue(os.path.isdir(tmp_dir))
            self.assertTrue(os.path.isfile(os.path.join(tmp_dir, "main.py")))
            # Cleanup
            sb.stop()
            sb.cleanup()

    def test_prepare_does_not_modify_original(self):
        from build.sandbox import SandboxRun, SandboxOptions
        with tempfile.TemporaryDirectory() as tmp:
            self._make_project(tmp)
            original_main = open(os.path.join(tmp, "main.py")).read()
            sb = SandboxRun(tmp, SandboxOptions(mode="clean"))
            sb.prepare()
            sb.cleanup()
            # Original unchanged
            self.assertEqual(open(os.path.join(tmp, "main.py")).read(), original_main)

    def test_cleanup_removes_temp_dir(self):
        from build.sandbox import SandboxRun, SandboxOptions
        with tempfile.TemporaryDirectory() as tmp:
            self._make_project(tmp)
            sb = SandboxRun(tmp, SandboxOptions(mode="clean"))
            tmp_dir = sb.prepare()
            self.assertTrue(os.path.isdir(tmp_dir))
            sb.cleanup()
            self.assertFalse(os.path.isdir(tmp_dir))

    def test_log_retention_after_cleanup(self):
        from build.sandbox import SandboxRun, SandboxOptions
        with tempfile.TemporaryDirectory() as tmp:
            self._make_project(tmp)
            sb = SandboxRun(tmp, SandboxOptions(mode="clean", keep_log_runs=3))
            sb.prepare()
            log_dir = sb.cleanup()
            # Log dir should be created even if no process ran
            if log_dir:
                self.assertTrue(os.path.isdir(log_dir))

    def test_start_runs_process(self):
        from build.sandbox import SandboxRun, SandboxOptions
        with tempfile.TemporaryDirectory() as tmp:
            self._make_project(tmp)
            sb = SandboxRun(tmp, SandboxOptions(mode="clean"))
            sb.prepare()
            proc = sb.start("python main.py")
            time.sleep(0.5)
            info = proc.info()
            self.assertIn(info["status"], ("running", "stopped", "crashed"))
            sb.stop()
            sb.cleanup()

    def test_stdout_captured(self):
        from build.sandbox import SandboxRun, SandboxOptions
        lines = []
        with tempfile.TemporaryDirectory() as tmp:
            self._make_project(tmp)
            sb = SandboxRun(tmp, SandboxOptions(mode="clean"))
            sb.on_stdout(lines.append)
            sb.prepare()
            sb.start("python main.py")
            time.sleep(0.6)
            sb.cleanup()
        self.assertTrue(any("sandbox ok" in l for l in lines))

    def test_minified_mode_prepares(self):
        from build.sandbox import SandboxRun, SandboxOptions
        with tempfile.TemporaryDirectory() as tmp:
            self._make_project(tmp)
            sb = SandboxRun(tmp, SandboxOptions(mode="minified"))
            tmp_dir = sb.prepare()
            # Temp dir should exist and have main.py
            self.assertTrue(os.path.isfile(os.path.join(tmp_dir, "main.py")))
            sb.cleanup()

    def test_list_sandbox_logs(self):
        from build.sandbox import SandboxRun, SandboxOptions, list_sandbox_logs
        with tempfile.TemporaryDirectory() as tmp:
            self._make_project(tmp)
            sb = SandboxRun(tmp, SandboxOptions(mode="clean", keep_log_runs=5))
            sb.prepare()
            sb.cleanup()
            logs = list_sandbox_logs(tmp)
            # May be empty if no logs were generated, but should not error
            self.assertIsInstance(logs, list)

    def test_is_running_false_after_stop(self):
        from build.sandbox import SandboxRun, SandboxOptions
        with tempfile.TemporaryDirectory() as tmp:
            self._make_project(tmp)
            sb = SandboxRun(tmp, SandboxOptions(mode="clean"))
            sb.prepare()
            sb.start("python main.py")
            time.sleep(0.5)
            sb.stop()
            time.sleep(0.3)
            # After stop, is_running should be False
            self.assertFalse(sb.is_running)
            sb.cleanup()


if __name__ == "__main__":
    unittest.main(verbosity=2)
