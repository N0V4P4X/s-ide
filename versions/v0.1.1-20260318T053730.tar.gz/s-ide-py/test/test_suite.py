"""
test/test_suite.py
==================
S-IDE core test suite. Uses only stdlib (unittest) — no pytest required,
though pytest will discover and run these fine.

Test groups
-----------
TestPythonParser    — AST-based python_parser
TestJSParser        — regex-based js_parser
TestJSONParser      — json_parser (package.json, tsconfig, generic)
TestShellParser     — shell_parser
TestWalker          — directory walker ignore logic
TestProjectConfig   — side.project.json load/save/init/bump
TestResolveEdges    — import → edge resolution
TestLayout          — auto-layout position assignment
TestDocCheck        — README / empty-module audit
TestProjectParser   — full parse pipeline on a synthetic project
TestVersionManager  — archive, extract, list, compress
TestProcessManager  — spawn, logs, stop
"""

from __future__ import annotations
import json
import os
import sys
import tarfile
import tempfile
import time
import unittest

# ── Make sure parent dir is on sys.path so imports resolve ───────────────────
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if ROOT not in sys.path:
    sys.path.insert(0, ROOT)

# ── Imports under test ────────────────────────────────────────────────────────
from parser.parsers.python_parser import parse_python
from parser.parsers.js_parser import parse_javascript
from parser.parsers.json_parser import parse_json
from parser.parsers.shell_parser import parse_shell
from parser.walker import walk_directory, make_node_id, _should_ignore
from parser.project_config import load_project_config, save_project_config, init_project_config, bump_version
from parser.resolve_edges import resolve_edges, collect_external_packages
from parser.layout import assign_positions
from parser.doc_check import audit_docs
from parser.project_parser import parse_project
from version.version_manager import archive_version, apply_update, list_versions, compress_loose
from process.process_manager import ProcessManager
from graph.types import FileNode, Edge, Position, ImportRecord


# ── Helpers ───────────────────────────────────────────────────────────────────

def _tmp_project(*files: tuple[str, str]) -> tempfile.TemporaryDirectory:
    """
    Create a temporary directory pre-populated with (relative_path, content) files.
    Use as a context manager: `with _tmp_project(...) as tmp_dir: ...`
    The context variable is the directory path string.
    """
    tmp = tempfile.TemporaryDirectory()
    for rel_path, file_content in files:
        full = os.path.join(tmp.name, rel_path)
        os.makedirs(os.path.dirname(full), exist_ok=True)
        with open(full, "w", encoding="utf-8") as f:
            f.write(file_content)
    return tmp


# ═══════════════════════════════════════════════════════════════════════════════
# Parser tests
# ═══════════════════════════════════════════════════════════════════════════════

class TestPythonParser(unittest.TestCase):

    def test_basic_import(self):
        src = "import os\nimport sys\n"
        r = parse_python(src)
        sources = [i.source for i in r["imports"]]
        self.assertIn("os", sources)
        self.assertIn("sys", sources)

    def test_from_import(self):
        src = "from os.path import join, exists\n"
        r = parse_python(src)
        self.assertEqual(len(r["imports"]), 1)
        imp = r["imports"][0]
        self.assertEqual(imp.type, "from-import")
        self.assertEqual(imp.source, "os.path")
        self.assertIn("join", imp.names)

    def test_relative_import(self):
        src = "from . import utils\nfrom ..core import Base\n"
        r = parse_python(src)
        sources = [i.source for i in r["imports"]]
        self.assertIn(".", sources)
        self.assertIn("..core", sources)

    def test_function_definition(self):
        src = "def hello(name):\n    pass\n"
        r = parse_python(src)
        defs = [d.name for d in r["definitions"]]
        self.assertIn("hello", defs)

    def test_async_function(self):
        src = "async def fetch():\n    pass\n"
        r = parse_python(src)
        d = r["definitions"][0]
        self.assertTrue(d.is_async)
        self.assertEqual(d.name, "fetch")

    def test_class_with_base(self):
        src = "class Dog(Animal):\n    pass\n"
        r = parse_python(src)
        cls = r["definitions"][0]
        self.assertEqual(cls.kind, "class")
        self.assertIn("Animal", cls.bases)

    def test_dunder_method(self):
        src = "class Foo:\n    def __init__(self):\n        pass\n"
        r = parse_python(src)
        dunder = next(d for d in r["definitions"] if d.name == "__init__")
        self.assertEqual(dunder.kind, "dunder")

    def test_all_export(self):
        src = '__all__ = ["foo", "bar"]\ndef foo(): pass\ndef bar(): pass\n'
        r = parse_python(src)
        all_exp = next((e for e in r["exports"] if e.type == "__all__"), None)
        self.assertIsNotNone(all_exp)
        self.assertIn("foo", all_exp.names)

    def test_implicit_exports(self):
        src = "def public(): pass\ndef _private(): pass\n"
        r = parse_python(src)
        names = [e.name for e in r["exports"] if e.type == "implicit"]
        self.assertIn("public", names)
        self.assertNotIn("_private", names)

    def test_entrypoint_tag(self):
        src = "if __name__ == '__main__':\n    main()\n"
        r = parse_python(src)
        self.assertIn("entrypoint", r["tags"])

    def test_syntax_error_fallback(self):
        src = "def broken(\n    pass\n"
        r = parse_python(src)
        self.assertTrue(len(r["errors"]) > 0)

    def test_flask_tag(self):
        src = "from flask import Flask\n"
        r = parse_python(src)
        self.assertIn("flask", r["tags"])

    def test_star_import(self):
        src = "from utils import *\n"
        r = parse_python(src)
        self.assertEqual(r["imports"][0].type, "from-import-all")


class TestJSParser(unittest.TestCase):

    def test_es_default_import(self):
        src = "import React from 'react';\n"
        r = parse_javascript(src)
        self.assertEqual(r["imports"][0].type, "es-default")
        self.assertEqual(r["imports"][0].source, "react")

    def test_es_named_import(self):
        src = "import { useState, useEffect } from 'react';\n"
        r = parse_javascript(src)
        imp = r["imports"][0]
        self.assertEqual(imp.type, "es-named")
        self.assertIn("useState", imp.names)

    def test_cjs_require(self):
        src = "const path = require('path');\n"
        r = parse_javascript(src)
        self.assertEqual(r["imports"][0].type, "cjs-require")

    def test_export_default(self):
        src = "export default MyComponent;\n"
        r = parse_javascript(src)
        self.assertEqual(r["exports"][0].type, "default")
        self.assertEqual(r["exports"][0].name, "MyComponent")

    def test_reexport(self):
        src = "export { foo, bar } from './utils';\n"
        r = parse_javascript(src)
        exp = r["exports"][0]
        self.assertEqual(exp.type, "re-export")
        self.assertEqual(exp.source, "./utils")

    def test_function_def(self):
        src = "function greet(name) { return name; }\n"
        r = parse_javascript(src)
        self.assertIn("greet", [d.name for d in r["definitions"]])

    def test_comment_stripping(self):
        src = "// import foo from 'not-real';\nimport bar from 'real';\n"
        r = parse_javascript(src)
        sources = [i.source for i in r["imports"]]
        self.assertNotIn("not-real", sources)
        self.assertIn("real", sources)

    def test_react_tag(self):
        src = "import React from 'react';\n"
        r = parse_javascript(src)
        self.assertIn("react", r["tags"])


class TestJSONParser(unittest.TestCase):

    def test_package_json(self):
        src = json.dumps({
            "name": "my-app",
            "dependencies": {"express": "^4.0.0"},
            "scripts": {"start": "node index.js"},
        })
        r = parse_json(src, "package.json")
        self.assertIn("package-manifest", r["tags"])
        srcs = [i.source for i in r["imports"]]
        self.assertIn("express", srcs)
        script_names = [d.name for d in r["definitions"]]
        self.assertIn("start", script_names)

    def test_malformed_json(self):
        r = parse_json("{not valid}", "config.json")
        self.assertTrue(len(r["errors"]) > 0)

    def test_tsconfig(self):
        src = json.dumps({"compilerOptions": {"paths": {"@utils/*": ["src/utils/*"]}}})
        r = parse_json(src, "tsconfig.json")
        self.assertIn("typescript-config", r["tags"])


class TestShellParser(unittest.TestCase):

    def test_source_import(self):
        src = "source ./lib/helpers.sh\n"
        r = parse_shell(src)
        self.assertEqual(r["imports"][0].type, "source")
        self.assertIn("./lib/helpers.sh", r["imports"][0].source)

    def test_env_var_export(self):
        src = "export DATABASE_URL=postgres://localhost\n"
        r = parse_shell(src)
        names = [e.name for e in r["exports"]]
        self.assertIn("DATABASE_URL", names)

    def test_function_def(self):
        src = "function setup() {\n  echo hi\n}\n"
        r = parse_shell(src)
        self.assertIn("setup", [d.name for d in r["definitions"]])

    def test_docker_tag(self):
        src = "docker build -t myimage .\n"
        r = parse_shell(src)
        self.assertIn("docker", r["tags"])


# ═══════════════════════════════════════════════════════════════════════════════
# Walker tests
# ═══════════════════════════════════════════════════════════════════════════════

class TestWalker(unittest.TestCase):

    def test_basic_walk(self):
        with _tmp_project(
            ("main.py", "# main"),
            ("utils/helpers.py", "# helpers"),
        ) as tmp:
            files = walk_directory(tmp)
            rel_paths = [f.relative_path for f in files]
            self.assertIn("main.py", rel_paths)
            self.assertIn("utils/helpers.py", rel_paths)

    def test_node_modules_ignored(self):
        with _tmp_project(
            ("index.js", ""),
            ("node_modules/express/index.js", ""),
        ) as tmp:
            files = walk_directory(tmp)
            paths = [f.relative_path for f in files]
            self.assertIn("index.js", paths)
            self.assertFalse(any("node_modules" in p for p in paths))

    def test_pycache_ignored(self):
        with _tmp_project(
            ("app.py", ""),
            ("__pycache__/app.cpython-311.pyc", ""),
        ) as tmp:
            files = walk_directory(tmp)
            paths = [f.relative_path for f in files]
            self.assertFalse(any("__pycache__" in p for p in paths))

    def test_extra_ignore(self):
        with _tmp_project(
            ("src/main.py", ""),
            ("dist/bundle.js", ""),
        ) as tmp:
            files = walk_directory(tmp, extra_ignore=["dist"])
            paths = [f.relative_path for f in files]
            self.assertFalse(any("dist" in p for p in paths))

    def test_make_node_id(self):
        self.assertEqual(make_node_id("src/utils/helpers.py"), "src_utils_helpers_py")
        self.assertEqual(make_node_id("main.py"), "main_py")

    def test_hidden_files_ignored(self):
        with _tmp_project(
            ("visible.py", ""),
            (".hidden.py", ""),
        ) as tmp:
            files = walk_directory(tmp)
            paths = [f.relative_path for f in files]
            self.assertIn("visible.py", paths)
            self.assertNotIn(".hidden.py", paths)


# ═══════════════════════════════════════════════════════════════════════════════
# Project config tests
# ═══════════════════════════════════════════════════════════════════════════════

class TestProjectConfig(unittest.TestCase):

    def test_bump_patch(self):
        self.assertEqual(bump_version("1.2.3", "patch"), "1.2.4")

    def test_bump_minor(self):
        self.assertEqual(bump_version("1.2.3", "minor"), "1.3.0")

    def test_bump_major(self):
        self.assertEqual(bump_version("1.2.3", "major"), "2.0.0")

    def test_bump_defaults_patch(self):
        self.assertEqual(bump_version("0.0.1"), "0.0.2")

    def test_init_creates_config(self):
        with tempfile.TemporaryDirectory() as tmp:
            config = init_project_config(tmp)
            self.assertTrue(os.path.exists(os.path.join(tmp, "side.project.json")))
            self.assertEqual(config["name"], os.path.basename(tmp))

    def test_load_missing_returns_defaults(self):
        with tempfile.TemporaryDirectory() as tmp:
            config = load_project_config(tmp)
            self.assertFalse(config["_exists"])
            self.assertIn("versions", config)

    def test_save_and_reload(self):
        with tempfile.TemporaryDirectory() as tmp:
            config = init_project_config(tmp)
            config["version"] = "9.9.9"
            save_project_config(tmp, config)
            reloaded = load_project_config(tmp)
            self.assertEqual(reloaded["version"], "9.9.9")

    def test_no_internal_keys_saved(self):
        with tempfile.TemporaryDirectory() as tmp:
            config = init_project_config(tmp)
            config_path = os.path.join(tmp, "side.project.json")
            with open(config_path) as f:
                raw = json.load(f)
            for key in raw:
                self.assertFalse(key.startswith("_"), f"Internal key found: {key}")


# ═══════════════════════════════════════════════════════════════════════════════
# Edge resolver tests
# ═══════════════════════════════════════════════════════════════════════════════

class TestResolveEdges(unittest.TestCase):

    def _make_node(self, rel_path: str, imports=None) -> FileNode:
        return FileNode(
            id=make_node_id(rel_path),
            label=os.path.basename(rel_path),
            path=rel_path,
            full_path=f"/proj/{rel_path}",
            category="python",
            ext=".py",
            imports=imports or [],
        )

    def test_resolves_relative_import(self):
        main = self._make_node("main.py", [
            ImportRecord(type="from-import", source="utils", names=["helper"])
        ])
        utils = self._make_node("utils.py")
        file_index = {"main.py": main.id, "utils.py": utils.id}
        edges = resolve_edges([main, utils], file_index, "/proj")
        self.assertTrue(any(e.source == main.id and e.target == utils.id for e in edges))

    def test_external_package(self):
        node = self._make_node("app.py", [
            ImportRecord(type="import", source="requests")
        ])
        file_index = {"app.py": node.id}
        edges = resolve_edges([node], file_index, "/proj")
        ext_edges = [e for e in edges if e.is_external]
        self.assertTrue(len(ext_edges) > 0)
        self.assertEqual(ext_edges[0].external_pkg, "requests")

    def test_no_duplicate_edges(self):
        main = self._make_node("main.py", [
            ImportRecord(type="from-import", source="utils", names=["a"]),
            ImportRecord(type="from-import", source="utils", names=["b"]),
        ])
        utils = self._make_node("utils.py")
        file_index = {"main.py": main.id, "utils.py": utils.id}
        edges = resolve_edges([main, utils], file_index, "/proj")
        internal = [e for e in edges if not e.is_external]
        self.assertEqual(len(internal), 1)

    def test_collect_external_packages(self):
        node = self._make_node("a.py", [ImportRecord(type="import", source="numpy")])
        file_index = {"a.py": node.id}
        edges = resolve_edges([node], file_index, "/proj")
        pkgs = collect_external_packages(edges)
        self.assertEqual(pkgs[0]["name"], "numpy")


# ═══════════════════════════════════════════════════════════════════════════════
# Layout tests
# ═══════════════════════════════════════════════════════════════════════════════

class TestLayout(unittest.TestCase):

    def _node(self, nid: str) -> FileNode:
        return FileNode(id=nid, label=nid, path=f"{nid}.py", full_path=f"/p/{nid}.py",
                        category="python", ext=".py")

    def test_all_nodes_get_positions(self):
        nodes = [self._node("a"), self._node("b"), self._node("c")]
        edges = [Edge(id="e0", source="a", target="b", type="import")]
        assign_positions(nodes, edges)
        for n in nodes:
            self.assertIsNotNone(n.position, f"{n.id} has no position")

    def test_root_at_zero(self):
        nodes = [self._node("root"), self._node("child")]
        edges = [Edge(id="e0", source="root", target="child", type="import")]
        assign_positions(nodes, edges)
        root = next(n for n in nodes if n.id == "root")
        child = next(n for n in nodes if n.id == "child")
        self.assertEqual(root.position.x, 0.0)
        self.assertGreater(child.position.x, root.position.x)

    def test_empty_graph(self):
        assign_positions([], [])   # should not raise


# ═══════════════════════════════════════════════════════════════════════════════
# Doc check tests
# ═══════════════════════════════════════════════════════════════════════════════

class TestDocCheck(unittest.TestCase):

    def _node(self, path: str, **kwargs) -> FileNode:
        return FileNode(
            id=make_node_id(path), label=os.path.basename(path),
            path=path, full_path=f"/p/{path}",
            category=kwargs.get("category", "python"), ext=kwargs.get("ext", ".py"),
            imports=kwargs.get("imports", []),
            exports=kwargs.get("exports", []),
            definitions=kwargs.get("definitions", []),
        )

    def test_missing_readme_warning(self):
        nodes = [self._node("src/main.py")]
        audit = audit_docs("/p", nodes)
        types = [w.type for w in audit.warnings]
        self.assertIn("missing-readme", types)

    def test_healthy_with_readme(self):
        from graph.types import ExportRecord, Definition
        src_node = self._node("src/main.py",
                               exports=[ExportRecord(type="implicit", name="main", kind="function")],
                               definitions=[Definition(name="main", kind="function", line=1)])
        readme = self._node("src/README.md", category="docs", ext=".md")
        audit = audit_docs("/p", [src_node, readme])
        missing = [w for w in audit.warnings if w.type == "missing-readme"]
        self.assertEqual(len(missing), 0)


# ═══════════════════════════════════════════════════════════════════════════════
# Full pipeline test
# ═══════════════════════════════════════════════════════════════════════════════

class TestProjectParser(unittest.TestCase):

    def test_parse_synthetic_project(self):
        with _tmp_project(
            ("main.py", "from utils.helpers import greet\n\nif __name__ == '__main__':\n    greet('world')\n"),
            ("utils/__init__.py", ""),
            ("utils/helpers.py", "def greet(name):\n    print(f'Hello, {name}')\n"),
            ("README.md", "# Test project\n"),
        ) as tmp:
            graph = parse_project(tmp)
            d = graph.to_dict()

            self.assertGreaterEqual(d["meta"]["totalFiles"], 3)
            node_paths = [n["path"] for n in d["nodes"]]
            self.assertIn("main.py", node_paths)
            self.assertIn("utils/helpers.py", node_paths)

            # main.py should have an edge to utils/helpers.py
            edges = d["edges"]
            main_id = make_node_id("main.py")
            helpers_id = make_node_id("utils/helpers.py")
            internal = [e for e in edges if not e.get("isExternal")]
            found = any(e["source"] == main_id and e["target"] == helpers_id for e in internal)
            self.assertTrue(found, "Expected edge main.py → utils/helpers.py")

    def test_parse_returns_positions(self):
        with _tmp_project(("app.py", "import os\n")) as tmp:
            graph = parse_project(tmp)
            for node in graph.nodes:
                self.assertIsNotNone(node.position, f"{node.path} missing position")

    def test_graph_serialises_to_json(self):
        with _tmp_project(("hello.py", "print('hi')\n")) as tmp:
            graph = parse_project(tmp)
            # Should not raise
            txt = json.dumps(graph.to_dict())
            self.assertIn("nodes", txt)


# ═══════════════════════════════════════════════════════════════════════════════
# Version manager tests
# ═══════════════════════════════════════════════════════════════════════════════

class TestVersionManager(unittest.TestCase):

    def _make_project(self, tmp_dir: str) -> None:
        os.makedirs(os.path.join(tmp_dir, "src"), exist_ok=True)
        with open(os.path.join(tmp_dir, "main.py"), "w") as f:
            f.write("print('hello')\n")
        with open(os.path.join(tmp_dir, "src", "utils.py"), "w") as f:
            f.write("def helper(): pass\n")
        cfg = {"name": "testproj", "version": "1.0.0",
               "versions": {"dir": "versions", "compress": True, "keep": 5}}
        with open(os.path.join(tmp_dir, "side.project.json"), "w") as f:
            json.dump(cfg, f)

    def test_archive_creates_tarball(self):
        with tempfile.TemporaryDirectory() as tmp:
            self._make_project(tmp)
            path = archive_version(tmp)
            self.assertTrue(os.path.exists(path))
            self.assertTrue(path.endswith(".tar.gz"))

    def test_archive_is_valid_tar(self):
        with tempfile.TemporaryDirectory() as tmp:
            self._make_project(tmp)
            path = archive_version(tmp)
            self.assertTrue(tarfile.is_tarfile(path))

    def test_list_versions(self):
        with tempfile.TemporaryDirectory() as tmp:
            self._make_project(tmp)
            archive_version(tmp)
            versions = list_versions(tmp)
            self.assertEqual(len(versions), 1)
            self.assertEqual(versions[0]["type"], "tarball")

    def test_apply_update(self):
        with tempfile.TemporaryDirectory() as proj_dir:
            self._make_project(proj_dir)

            # Build an "update" tarball from a temp dir
            with tempfile.TemporaryDirectory() as update_src:
                os.makedirs(os.path.join(update_src, "testproj"))
                with open(os.path.join(update_src, "testproj", "new_file.py"), "w") as f:
                    f.write("# new!\n")
                tarball = os.path.join(update_src, "update.tar.gz")
                with tarfile.open(tarball, "w:gz") as tar:
                    tar.add(os.path.join(update_src, "testproj"), arcname="testproj")

                new_ver, arch = apply_update(proj_dir, tarball, "minor")
                self.assertEqual(new_ver, "1.1.0")
                self.assertTrue(os.path.exists(arch))
                self.assertTrue(os.path.exists(os.path.join(proj_dir, "new_file.py")))

    def test_versions_dir_excluded_from_archive(self):
        with tempfile.TemporaryDirectory() as tmp:
            self._make_project(tmp)
            archive_version(tmp)  # creates versions/
            path = archive_version(tmp)  # second archive
            with tarfile.open(path, "r:gz") as tar:
                names = tar.getnames()
            self.assertFalse(any("versions" in n for n in names))


# ═══════════════════════════════════════════════════════════════════════════════
# Process manager tests
# ═══════════════════════════════════════════════════════════════════════════════

class TestProcessManager(unittest.TestCase):

    def test_start_and_exit(self):
        mgr = ProcessManager()
        proc = mgr.start(name="echo", command="echo hello")
        time.sleep(0.5)
        info = proc.info()
        self.assertIn(info["status"], ("stopped", "crashed", "running"))

    def test_logs_captured(self):
        mgr = ProcessManager()
        proc = mgr.start(name="echo", command="echo captured_line")
        time.sleep(0.5)
        logs = proc.logs()
        lines = [entry["line"] for entry in logs]
        self.assertTrue(any("captured_line" in l for l in lines))

    def test_stop(self):
        mgr = ProcessManager()
        # Use a long-running process
        proc = mgr.start(name="sleep", command="sleep 30")
        time.sleep(0.2)
        ok = mgr.stop(proc.id)
        self.assertTrue(ok)

    def test_list(self):
        mgr = ProcessManager()
        mgr.start(name="p1", command="echo a")
        mgr.start(name="p2", command="echo b")
        time.sleep(0.3)
        listing = mgr.list()
        self.assertEqual(len(listing), 2)

    def test_on_stdout_callback(self):
        received = []
        mgr = ProcessManager()
        proc = mgr.start(name="cb-test", command="echo callback_works")
        proc.on_stdout(received.append)
        time.sleep(0.5)
        # Callback may fire after attachment; check logs as fallback
        logs = [e["line"] for e in proc.logs()]
        self.assertTrue(
            any("callback_works" in l for l in logs),
            "Expected output not found in logs"
        )

    def test_purge_stopped(self):
        mgr = ProcessManager()
        mgr.start(name="quick", command="echo done")
        time.sleep(0.5)
        removed = mgr.purge_stopped()
        self.assertGreaterEqual(removed, 0)


# ── Runner ────────────────────────────────────────────────────────────────────

if __name__ == "__main__":
    unittest.main(verbosity=2)
