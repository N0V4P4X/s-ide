"""
monitor/perf.py
===============
Performance monitoring for S-IDE.

Tracks two categories of metrics:

1. Parse pipeline timing
   Each stage of parse_project (walk, per-file parse, edge resolution,
   layout, doc-check) is timed and stored in the graph JSON under
   meta.perf.  The GUI displays this as a pipeline breakdown.

2. Process resource usage
   For each ManagedProcess, samples CPU % and RSS memory every N seconds
   using /proc/<pid>/stat (Linux) or psutil if available.  Stored in a
   rolling window so the GUI can plot a live sparkline.

Usage
-----
    # Wrapping the parser:
    from monitor.perf import ParseTimer
    timer = ParseTimer()
    with timer.stage("walk"):
        files = walk_directory(root)
    with timer.stage("parse_files"):
        ...
    report = timer.report()   # → dict ready for graph meta

    # Process sampling:
    from monitor.perf import ProcessMonitor
    mon = ProcessMonitor(proc_mgr)
    mon.start()               # background thread, samples every 2s
    mon.stop()
    snapshot = mon.snapshot() # → {proc_id: {cpu, rss_mb, samples: [...]}}
"""

from __future__ import annotations
import os
import sys
import time
import threading
from collections import deque
from contextlib import contextmanager
from typing import Iterator


# ── Parse pipeline timer ──────────────────────────────────────────────────────

class ParseTimer:
    """
    Context-manager based stage timer for the parse pipeline.

    with timer.stage("walk"):
        ...
    with timer.stage("per_file"):
        ...
    report = timer.report()
    """

    def __init__(self) -> None:
        self._stages: list[tuple[str, float]] = []   # (name, elapsed_ms)
        self._start = time.monotonic()
        self._stage_start: float | None = None
        self._current: str | None = None

    @contextmanager
    def stage(self, name: str) -> Iterator[None]:
        t0 = time.monotonic()
        self._current = name
        try:
            yield
        finally:
            elapsed = (time.monotonic() - t0) * 1000
            self._stages.append((name, round(elapsed, 2)))
            self._current = None

    def total_ms(self) -> float:
        return round((time.monotonic() - self._start) * 1000, 2)

    def report(self) -> dict:
        """Return a dict suitable for embedding in graph meta.perf."""
        return {
            "total_ms":  self.total_ms(),
            "stages":    [{"name": n, "ms": ms} for n, ms in self._stages],
            "slowest":   max(self._stages, key=lambda x: x[1])[0] if self._stages else None,
        }


# ── Process resource sampler ──────────────────────────────────────────────────

_HAVE_PSUTIL = False
try:
    import psutil  # type: ignore
    _HAVE_PSUTIL = True
except ImportError:
    pass


def _sample_pid_linux(pid: int) -> tuple[float, float] | None:
    """
    Sample a process on Linux using /proc/<pid>/stat.
    Returns (cpu_percent_approx, rss_mb) or None if the process is gone.
    cpu_percent here is a rough delta over the sampling interval.
    """
    try:
        stat_path = f"/proc/{pid}/stat"
        status_path = f"/proc/{pid}/status"
        if not os.path.exists(stat_path):
            return None

        # RSS from /proc/pid/status
        rss_kb = 0
        with open(status_path) as f:
            for line in f:
                if line.startswith("VmRSS:"):
                    rss_kb = int(line.split()[1])
                    break

        return (0.0, round(rss_kb / 1024, 2))  # cpu% needs two samples
    except (OSError, ValueError):
        return None


def _sample_pid(pid: int) -> tuple[float, float] | None:
    """
    Return (cpu_percent, rss_mb) for a pid.
    Uses psutil if available, else Linux /proc fallback, else None.
    """
    if _HAVE_PSUTIL:
        try:
            p = psutil.Process(pid)
            cpu = p.cpu_percent(interval=None)
            rss = round(p.memory_info().rss / 1024 / 1024, 2)
            return (cpu, rss)
        except (psutil.NoSuchProcess, psutil.AccessDenied):
            return None
    if sys.platform.startswith("linux"):
        return _sample_pid_linux(pid)
    return None


class ProcessMonitor:
    """
    Background sampler for all processes in a ProcessManager.

    Stores a rolling window of (timestamp, cpu%, rss_mb) tuples per
    process ID.  The GUI reads snapshot() to render sparklines.
    """

    SAMPLE_INTERVAL = 2.0    # seconds between samples
    WINDOW_SIZE     = 120    # samples kept per process (~4 min at 2s)

    def __init__(self, proc_mgr) -> None:
        self._mgr    = proc_mgr
        self._data:  dict[str, deque] = {}   # proc_id → deque of dicts
        self._lock   = threading.Lock()
        self._thread: threading.Thread | None = None
        self._stop_event = threading.Event()
        # Prime psutil cpu_percent (first call always returns 0)
        if _HAVE_PSUTIL:
            for info in proc_mgr.list():
                if info.get("pid"):
                    try:
                        psutil.Process(info["pid"]).cpu_percent(interval=None)
                    except Exception:
                        pass

    def start(self) -> None:
        """Start background sampling thread."""
        if self._thread and self._thread.is_alive():
            return
        self._stop_event.clear()
        self._thread = threading.Thread(
            target=self._loop, name="proc-monitor", daemon=True
        )
        self._thread.start()

    def stop(self) -> None:
        self._stop_event.set()

    def _loop(self) -> None:
        while not self._stop_event.wait(timeout=self.SAMPLE_INTERVAL):
            self._sample_all()

    def _sample_all(self) -> None:
        for info in self._mgr.list():
            pid = info.get("pid")
            proc_id = info.get("id")
            if not pid or not proc_id:
                continue
            result = _sample_pid(pid)
            if result is None:
                continue
            cpu, rss = result
            entry = {
                "ts":  round(time.time(), 1),
                "cpu": cpu,
                "rss": rss,
            }
            with self._lock:
                if proc_id not in self._data:
                    self._data[proc_id] = deque(maxlen=self.WINDOW_SIZE)
                self._data[proc_id].append(entry)

    def snapshot(self) -> dict:
        """
        Return current metrics for all sampled processes.

        {
          proc_id: {
            "latest": {"cpu": float, "rss": float, "ts": float},
            "samples": [{"ts":..., "cpu":..., "rss":...}, ...]
          }
        }
        """
        with self._lock:
            result = {}
            for proc_id, window in self._data.items():
                samples = list(window)
                if not samples:
                    continue
                result[proc_id] = {
                    "latest":  samples[-1],
                    "samples": samples,
                }
            return result

    def latest(self, proc_id: str) -> dict | None:
        """Return the most recent sample for a process, or None."""
        with self._lock:
            window = self._data.get(proc_id)
            if window:
                return window[-1]
        return None
