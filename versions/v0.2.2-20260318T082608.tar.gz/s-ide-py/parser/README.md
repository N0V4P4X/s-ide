# parser/

Project dependency graph parser — copied from the `nodegraph-parser` module.
Walks a directory tree and produces a structured `NodeGraph` JSON describing
every file and how they relate to each other.

## Entry points

- **`index.js`** — CLI: `node parser/index.js <project-path> [output.json]`
- **`projectParser.js`** — Library: `import { parseProject } from './parser/projectParser.js'`

## Pipeline

```
projectParser.js
  ├── walks directory (skipping node_modules, .git, dist, etc.)
  ├── dispatches each file to parsers/
  ├── resolveEdges.js  (import strings → node IDs + external virtual nodes)
  ├── docCheck.js      (README health audit)
  └── assignPositions  (topological layout → x,y per node)
```

## Output shape

```js
{
  version: "1.0.0",
  meta: { root, parsedAt, parseTime, totalFiles, totalEdges, languages, docs },
  nodes: [ FileNode, ... ],
  edges: [ GraphEdge, ... ]
}
```

`meta.docs` contains the documentation health audit:
```js
{
  healthy: false,
  summary: { missingReadmes, staleReadmes, emptyModules, total },
  warnings: [ { type, severity, dir, message, affectedFiles, staleSince? } ]
}
```

## Supported languages

| Extensions | Parser | Key extractions |
|-----------|--------|----------------|
| `.js .mjs .cjs .jsx .ts .tsx` | `parsers/javascript.js` | ES imports, CJS require, re-exports, functions, classes, components |
| `.py` | `parsers/python.js` | import/from-import, classes, functions, decorators, `__all__` |
| `.json` | `parsers/json.js` | package.json deps/scripts, tsconfig paths |
| `.sh .bash` | `parsers/shell.js` | source, script calls, env vars, functions |

See `parsers/README.md` for the parser contract interface.
