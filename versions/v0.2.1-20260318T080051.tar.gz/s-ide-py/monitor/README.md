# monitor/

Performance monitoring for the parse pipeline and running processes.

## perf.py

### ParseTimer

Times each stage of `parse_project` using context managers.
Results are embedded in `graph.to_dict()["meta"]["perf"]`:

```json
{
  "total_ms": 142,
  "slowest":  "parse_files",
  "stages": [
    {"name": "config",       "ms": 2.1},
    {"name": "walk",         "ms": 8.4},
    {"name": "parse_files",  "ms": 98.3},
    {"name": "resolve_edges","ms": 12.1},
    {"name": "layout",       "ms": 4.2},
    {"name": "doc_audit",    "ms": 11.0},
    {"name": "write_json",   "ms": 6.9}
  ]
}
```

The GUI performance panel reads this to show a stage breakdown bar.

### ProcessMonitor

Samples CPU% and RSS memory for all processes in a `ProcessManager`
every 2 seconds in a background thread.

Uses `psutil` if installed (more accurate), falls back to `/proc/<pid>/status`
on Linux, returns `None` on platforms without either.

```python
from monitor.perf import ProcessMonitor
mon = ProcessMonitor(proc_mgr)
mon.start()
snapshot = mon.snapshot()
# → {"proc_id": {"latest": {"cpu": 4.2, "rss": 38.1, "ts": ...}, "samples": [...]}}
mon.stop()
```
