# parser/parsers/

Language-specific extractors. Each is self-contained — no cross-dependencies.

## Contract

```js
export function parseLang(content, filePath) {
  return { imports, exports, definitions, calls, tags, errors }
}
```

Parsers **never throw** — internal errors go into `errors[]`.
All use regex-based parsing (no AST): fast, zero-dep, tolerates broken syntax.

## Files

- **`javascript.js`** — JS/TS/JSX/TSX. ES imports (default/named/namespace/side-effect), CJS require, dynamic import, re-exports, function/arrow/class/component defs, framework tag detection (react, express, next, electron…)
- **`python.js`** — import, from-import, class/function defs with decorators and indent depth, `__all__`, framework tags (flask, fastapi, asyncio…)
- **`json.js`** — package.json deps/devDeps/scripts, tsconfig path aliases, generic config keys
- **`shell.js`** — source/., script invocations, exported env vars, function defs, infra tags (docker, systemd, ssh…)
